<?php
/*Authors:Mai Hamduni & Kristina Mushkuv*/
require_once "functions/functions.php";
getrequire();
//session_start();

?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
  <head>
    <?php  getHead();?>
    
    <title>CompStore</title>
  </head>
  <body>
    <div class="row">
      <?php
      getLogo();
      getSearch();
      ProcessLoginOut();
      
      ?>
    </div>
    <div class="row2">
      <?php 
      getNav();?>
    </div>
    <?php 
    if(isset($_SESSION['Customer']))
    {
      $customerid=$_SESSION['Customer'];
      $db=new dbclass();
      $customer=$db->getCustomerById($customerid);
      
      if(count($customer)>0)
      {  
        foreach ($customer as $arr) 
        {

              echo'   <div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
            <form class="form form-signup" method="POST" style="margin-bottom: 50%">
               
                <h2 style="margin-top: 20%;margin-bottom:10%"> הפרטים שלי</h2>
                  <label for="inpuid">ת.ז</label>
                  
                <input type="text" name="Customer_id" value="'.$arr->getCustomerId().'" class="form-control" maxlength="9" pattern="[0-9]+   minlength="9" placeholder="ת.ז"  disabled>
                  
                <label for="inputFName">שם פרטי</label>
                <input type="text" name="Customer_name" value="'.$arr->getCustomerName().'" class="form-control" maxlength="20"  placeholder="שם פרטי" required>               
               
                       <label for="inputFName">שם משפחה</label>
                <input type="text" name="Customer_Lname" value="'.$arr->getCustomerLName().'" class="form-control" maxlength="20"  placeholder="שם משפחה" required>         
                
                <label for="inputTown" >כתובת מגורים</label>
                <input type="text" name="address" value="'.$arr->getCustomerAddress().'"class="form-control" placeholder="עיר" maxlength="15" required>

                <label for="inputPhoneNo" >מספר טלפון</label>
                <input type="text" name="phone" value="'.$arr->getCustomerPhone().'" class="form-control" placeholder="מספר פלאפון" maxlength="10" pattern="[0-9]+" minlength="10"   required>

                <label for="inpuEmail">מייל</label>
                <input type="text" name="email" value="'.$arr->getCustomeremail().'" class="form-control" placeholder="מייל" required autofocus>

                <button class="btn btn-lg btn-primary btn-block"  type="submit" name="updatecustomer" style="margin-top:10%; margin-bottom:1%;">עדכון</button>
            </form>';

       echo ' </div>
    </div>';    
               
        } 
      }
      if(isset($_POST['updatecustomer']))
      {
        $customer1=new customers();
        $customer1->setCustomerId($customerid);
        $customer1->setCustomerName($_POST['Customer_name']);
        $customer1->setCustomerLName($_POST['Customer_Lname']);
        $customer1->setCustomerPhone($_POST['phone']);
        $customer1->setCustomerAddress($_POST['address']);
        $customer1->setCustomeremail($_POST['email']);
        
        $db->UpdateCustomer($customer1);
        echo ' <div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
        <h2>הפרטים עודכנו בהצלחה</h2><br><br>
        </div></div>';

       
      }


  
    }
  



    ?>
  
    <div class="Footer">
      <?php getFooter();?>
    </div>
  </body>
</html>