  

<?php
/*Authors:Mai Hamduni & Kristina Mushkuv*/
require_once "functions/functions.php";
require_once "functions/FunctionsManager.php";
//require_once "phpToPDF/phpToPDF.php";
getrequire();
//session_start();
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
  <head>
    <?php  getHead();//Loading Libraries?>
    
    <title>CompStore</title>
  </head>
  <body>
    <div class="row">
      <?php
      getLogoManager();//Loading Logo
        getLoginOutManager();
      getNavManager();
      ?>
    </div>

     <?php 

     function _21()//Function Add Product
     {
     echo '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
         <h2 style="margin-top: 20%;margin-bottom:10%">הוספת מוצר</h2>';
       $product=new product(); 
            
            PageDesinge(); 
	      
        if(fillProduct($product)==false)
          return;

    	
        if(isset($_POST['Submit']))
         {

           $db=new dbclass();
           try {
                  
                 $resultproduct=$db->InsertProductManager($product);
     
                 echo '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
                 <h2 style="font-style:italic;">המוצר התווסף בהצלחה</h2>
                 </div></div><br><br>';
             }
        
          catch (PDOException $e) {
           //echo "יתכו שיש שכפול בקוד של מוצר או שמספר קטגוריה/תתקטגוריה לא נכון ";
		   echo $e;
          }

        }
    }

    function getemptyproduct(product $product)
    {
       $product->setProductName("");

          $product->setUnitPrice(0);
          $product->setdescription("");
          $product->setsubCategoryId("");
          $product->setQuantityProduct(0);


    }


   function _22()//Delete Product
    {
       echo  '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
         <h2 style="margin-top: 20%;margin-bottom:10%">מחיקת מוצרים</h2>
          <form class="form form-signup" method="POST" style="margin-bottom: 50%">';
         echo '  
            <label>שם מוצר</label>
           <select name="Product_id">';
           $db=new dbClass();
            $product=array();
            $product=$db->getProduct();
       foreach ( $product as $arr )
              {
                  echo' <option value='.$arr->getProductId().'>'.$arr->getProductName().'</option>;
                ';
          }
          echo'   

          </select><br><br><button class="btn btn-default" type="submit" name="deleteproduct">מחיקת מוצר</button></form></div></div>';

          if(isset($_POST['deleteproduct']))
          {
             if(isset($_POST['Product_id']))
             {
             
                $productId=$_POST['Product_id'];
              
                try
                {
                  $flag=0;
                  $check=$db->CheckiFproductInOrder($productId);
                  foreach ($check as $arr) {
                    $check2=$db->returnorderstatus($arr->getOrderId());
                    
                    if(count($check2))
                    {
                    
                      $flag=1;
                    }
                  
                  }
                  
                  if(!$flag)
                  {
                  $Delete=$db->DeleteProduct($productId) ;
                  echo '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
         <h2 style="margin-top: 5%;margin-bottom:10%">המוצר הוסר בהצלחה</h2>
         </div></div>' ;
         }  
                
                else
                {
                  echo '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
         <h3 style="margin-top: 20%;margin-bottom:10%; color:red;">לא ניתן למחוק את המוצר. מוצר נמצא בהזמנה שטרם בוצעה.</h3>
         </div></div>';
                  
                }
                }

                catch(PDOException $e)
                {
                  echo '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
         <h2 style="margin-top: 20%;margin-bottom:10%">מחיקת מוצר לא הצליחה</h2>
         </div></div>';
                 
                }
                 }
             }
           }


           


    function _23()//UPDATE product
    {
      
       echo '<div class="row">
         <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
         </div>
         <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
         <h2 style="margin-top: 20%;margin-bottom:10%">עדכון מוצר</h2>';

         $product=new product();
            
          UpdateProduct($product,0);
          getIdAndfillDetailes($product);
       if(isset($_POST['Update']))
       {    
         
          $db=new dbClass();
          $result=array();
         $product->setProductName($_POST['productname']);
         $product->setdescription($_POST['description']);
         $product->setUnitPrice($_POST['price']);
         $product->setQuantityProduct($_POST['quantity']);
         echo '<pre>';
         print_r($product);
         echo '</pre>';
          try{
			  $result=$db->UpdateProducts($product);
			  echo"המוצר עודכן בהצלחה";
		  }
		    catch (PDOException $e) {
           //echo "יתכן שיש שכפול בקוד של מוצר או שמספר קטגוריה/תתקטגוריה לא נכון ";
		  
       echo $e;
      
          }
        }
      }


      function UpdateProduct(product $prod,int $flag)
      {
        if(!$flag)
        {
           echo '  
            <form class="form form-signup" method="POST" style="margin-bottom: 50%">
            <label>מספר מוצר</label>
           <select name="Product_id">';
            $db=new dbClass();
            $product=array();
            $product=$db->getProduct();
       foreach ( $product as $arr )
              {
                  echo' <option value='.$arr->getProductId().'>'.$arr->getProductName().'</option>;
                ';
          }
          echo'   

          </select><br><br>
          <button class="btn btn-primary" type="submit" name="Next">המשך</button><br><br> ';
          return;
          
        }
        else
        {
            echo '



                <label for="inputFName">שם מוצר</label>
                <input type="text" name="productname" value="'.$prod->getProductName().'" class="form-control" maxlength="20"  placeholder="שם מוצר" required>
            
                <label for="inputTown" >תיאור</label>
                <input type="text" name="description" value="'.$prod->getDescription().'" class="form-control" placeholder="תיאור" maxlength="15" required>

                
                <label for="inoutquantity" >כמות</label>
                <input type="text" name="quantity" value="'.$prod->getQuantityProduct().'" class="form-control" placeholder="כמות" maxlength="15" required>

                <label for="inpuEmail">מחיר</label>
                <input type="text" name="price" value="'.$prod->getUnitPrice().'" class="form-control" placeholder="מחיר" required autofocus>

                <button class="btn btn-lg btn-primary btn-block"  type="submit" name="Update" style="margin-top:20%; margin-bottom:10%;">עדכן</button>
            </form>
       
        </div>
    </div>
  ';
       
        }
      }

      function  getIdAndfillDetailes(product $product)
      {
          
           if(isset($_POST['Next']))
           {
             
              $db=new dbClass();
              $productArr=array();
              $productArr=$db->getproductbyId($_POST['Product_id']);
              foreach ($productArr as $arr) 
              {
                 $product->setProductId($_POST['Product_id']);
                 $product->setProductName($arr->getProductName());
                 $product->setUnitPrice($arr->getUnitPrice());
                 $product->setdescription($arr->getDescription());
                 $product->setQuantityProduct($arr->getQuantityProduct());
              }

              UpdateProduct($product,1);
           }
      }


      function _24()//View Store Inventory
      {

        $db=new dbClass();
          $productarr=array();
          $productarr=$db->getProduct();//using query 
         $str="מוצרים במלאי החנות";
          tabledisieng($str);
          $productDetails=array();
          //put data in table      
        foreach ($productarr as $arr) {
          $productDetails=$db->getProductById($arr->getProductId());
          foreach ($productDetails as $product) {
            $productName=$product->getProductName();
          }
         echo'<tr> 
            <td>'.$arr->getProductId().'</td>
                <td>'.$productName.'</td>
                <td><img src="'.$arr->getimage().'"style="width:40%; hight:30%; margin-top:1%;"></td>
                <td " style="width:20%; hight:40%;">'.$arr->getDescription().' </td> 
                <td>'.$arr->getUnitPrice().'</td> 
                <td>'.$arr->getCategoryId().'</td>
                <td>'.$arr->getsubCategoryId().'</td>
                <td>'.$arr->getQuantityProduct().'</td>
              </tr>';
    }
     echo '<form method="POST">
    <button type="submit" name="ReportOutofStock" class="btn btn-primary">להוריד דוח</button>
    </form>';
    if(isset($_POST['ReportOutofStock']))
    {
      $file=fopen('Reports/מוצרים במלאי החנות .csv','w');
      $title=array(array('מספר מוצר','שם מוצר','מחיר','קטגוריה','תת קטגוריה', 'כמות'));
     
      fputs($file, chr(0xFF) . chr(0xFE));
    foreach ($title as $fields) {
    $out = '';
    foreach ($fields as $k => $v){
        $fields[$k] = mb_convert_encoding($v, 'UTF-16LE', 'UTF-8');        
    }
    $out = implode(chr(0x09).chr(0x00), $fields);
    fputs($file, $out.chr(0x0A).chr(0x00));
  }

  foreach ($productarr as $arr) {
    $out='';
    $arr2=array();
     $productDetails=$db->getProductById($arr->getProductId());
     foreach ($productDetails as $product) {
    $arr2[0]=mb_convert_encoding($product->getProductId(), 'UTF-16LE', 'UTF-8');
    $arr2[1]=mb_convert_encoding($product->getProductName(), 'UTF-16LE', 'UTF-8');
    $arr2[2]=mb_convert_encoding($product->getUnitPrice(), 'UTF-16LE', 'UTF-8');
    $arr2[3]=mb_convert_encoding($product->getCategoryId(), 'UTF-16LE', 'UTF-8');
    $arr2[4]=mb_convert_encoding($product->getsubCategoryId(), 'UTF-16LE', 'UTF-8');
    $arr2[5]=mb_convert_encoding($product->getQuantityProduct(), 'UTF-16LE', 'UTF-8');
    $out = implode(chr(0x09).chr(0x00), $arr2);
    fputs($file, $out.chr(0x0A).chr(0x00));
     }
   }
    fclose($file);
    }
  }

  function 
  tabledisieng (string $str)
  {
    //table desing
          echo ' <div class="row">
         <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">'.$str.'</h3>
            <div class="table table-sm" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מספר מוצר</th>
                            <th>שם מוצר </th>
                            <th>תמונה</th>
                             <th>תאור</th>
                            <th>מחיר</th>
                            <th>קטגוריה</th>
                            <th>תת קטגוריה</th>
                            <th>כמות</th>
                        </tr> 
                </thead> ';




        /*
         $db=new dbClass();
        $prdouctArr=$db->getProduct();
         echo ' <div class="row">
         <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">מוצרים במלאי החנות</h3>
            <div class="table table-sm" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מספר מוצר</th>
                            <th>שם מוצר </th>
                            <th>תמונה</th>
                            <th>תאור</th>
                            <th>מחיר</th>
                            <th>קטגוריה</th>
                            <th>תת קטגוריה</th>
                            <th>כמות</th>
                        </tr> 
                </thead> ';
                $productDetails=array();
                
               
        foreach ($prdouctArr as $arr) {
          $productDetails=$db->getProductById($arr->getProductId());
          foreach ($productDetails as $product) {
            $productName=$product->getProductName();
            //$CustomerAddress=$Customer->getCustomerAddress();
          }
         echo'<tr> 
            <td>'.$arr->getProductId().'</td>
                <td>'.$productName.'</td>
                <td><img src="'.$arr->getimage().'"style="width:40%; hight:30%; margin-top:1%;"></td>
                <td " style="width:20%; hight:40%;">'.$arr->getDescription().' </td> 
                <td>'.$arr->getUnitPrice().'</td> 
                <td>'.$arr->getCategoryId().'</td>
                <td>'.$arr->getsubCategoryId().'</td>
                 <td>'.$arr->getQuantityProduct().'</td>
              </tr>';
    }
  echo
             '<form method="POST"> <button type="submit" name="submit" class="btn btn-default" >להוריד דוח </button></form></table>
            </div>
        </div>
    </div>
';
    


   
            if(isset($_POST['submit']))
                 {
                
               $file=fopen("report.txt","w");
              foreach ($prdouctArr as $arr)
            {
             $productDetails=$db->getProductById($arr->getProductId());
               foreach ($productDetails as $product){
                    $productName=$product->getProductName();
                 }
                  fputs($file,$arr->getProductId());
                  fputs($file,$productName);
                   fputs($file,$arr->getUnitPrice());
                  fputs($file,$arr->getCategoryId() .'\n\n');
                 

            }
             fclose($file);
       }
  */

        }
      
  
  function details()
  {
     $db=new dbClass();
        $prdouctArr=$db->getProduct();
         echo ' <div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
            <h3>מוצרים במלאי החנות</h3>
            <div class="table table-sm" >
                <table class="table">
                    <thead>      <tr>
                            <th>מספר מוצר</th>
                            <th>שם מוצר </th>
                            <th>תמונה</th>
                            <th>מחיר</th>
                            <th>קטגוריה</th>
                            <th>תת קטגוריה</th>
                            <th>כמות</th>
                        </tr> 
                </thead> ';
                $productDetails=array();
                
               
        foreach ($prdouctArr as $arr) {
          $productDetails=$db->getProductById($arr->getProductId());
          foreach ($productDetails as $product) {
            $productName=$product->getProductName();
            //$CustomerAddress=$Customer->getCustomerAddress();
          }
         echo'<tr> 
            <td>'.$arr->getProductId().'</td>
                <td>'.$productName.'</td>
                <td><img src="'.$arr->getimage().'" style="width:100%;"></td>
                <td>'.$arr->getUnitPrice().'</td> 
                <td>'.$arr->getCategoryId().'</td>
                <td>'.$arr->getsubCategoryId().'</td>
                <td>'.$arr->getQuantityProduct().'</td>
              </tr>';
    }
  echo
             ' <button type="submit" class="btn btn-default" name="pdf">להוריד דוח </button></table>
            </div>
        </div>
    </div>
';
  }




     function fillProduct(product $product)//Function return true if all product data is ok else return false
     {
     
       if(isset($_POST['Product_Name'])&&isset($_POST['description'])&&isset($_POST['unit_price'])&&isset($_POST['category_id'])&&isset($_POST['subcategory_id'])&&isset($_POST['ProductAmount']))
      if(isset($_FILES['uploadedfile']['name']))
        {
         
           $target_path = 'images/'.$_FILES['uploadedfile']['name']; 
           $result = move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);

          if($result) {
            $product->setimage("images/".$_FILES['uploadedfile']['name']); 

        
        }
        else {
            echo '<br> <h3 style="margin-right: 35%; color:red;">שגיאה בהוספת מוצר</h3>'; 
             $product->setimage("");
        } 
         if($_GET['category']==23){
               //if(isset($_POST['Product_id']))

           $product->setProductId($_POST['Product_id']); 
         }

        if($_POST['unit_price']<=0)
        { 
          echo ' <div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
            <h4 style="color:red;">*לא ניתן להגדיר מחיר שלילי למוצר</h4></div></div><br><br>';
          return false;

        }      
          $product->setProductName($_POST['Product_Name']);
          $product->setUnitPrice($_POST['unit_price']);
          $product->setCategoryId($_POST['category_id']);
          $product->setdescription($_POST['description']);
          $product->setsubCategoryId($_POST['subcategory_id']);
          $product->setQuantityProduct($_POST['ProductAmount']);
          if($_POST['ProductAmount']<=0)
          {
            echo '<div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
            <h4 style="color:red;">*לא ניתן להגדיר כמות שלילית למוצר</h4></div></div><br><br>';
            return false;
          }
     }
     return true;
   }

    
     function PageDesinge()//Desinge of The Add And UPDATE pages
     {

     
        echo '
         <form enctype="multipart/form-data" method="POST">
         <input name="uploadedfile" type="file" />';
      
      echo '<form class="form form-signup" method="POST" style="margin-bottom: 50%">';
     

               
           echo '
                <label for="inpuid">שם מוצר</label>
                <input type="text" name="Product_Name" class="form-control" maxlength="30"  placeholder="שם מוצר" required autofocus>

                <label for="inputFName">תיאור</label>
                <input type="text" name="description" class="form-control" maxlength="250"  placeholder="תיאור" required>
                <label for="inputLName">מחיר</label>
                <input type="number"  name="unit_price"  minlength="9"class="form-control" placeholder="מחיר" required><br>';


          echo '  
            <label>קטגוריה:</label>
           <select name="category_id">';
           $db=new dbClass();
            $category=array();
            $category=$db->getCategories();
          
       foreach ( $category as $arr )
              {
                  echo' <option value='.$arr->getCategoryId().'>'.$arr->getCategoryName().'</option>';   
          }
          echo'   
          </select> <br><br> ';
         
         echo '  
            <label>תת קטגוריה:</label>
            <select name="subcategory_id">';

            $subcategory=array();
            $subcategory=$db-> getAllSubCategory();
       foreach ( $subcategory as $arr )
              {
                  echo' <option value='.$arr->getSubCategoryId().'>'.$arr->getSubCategoryName().'</option>;
                ';
          }
          echo'   

          </select> <br><br>
         <label>כמות מוצר </lable>
                <input type="number" name="ProductAmount"  class="form-control" placeholder="כמות מוצר " maxlength="15" required>
               </form> 
                <button class="btn btn-lg btn-primary btn-block" type="submit" style="margin-top:20%" name="Submit" action="ניהול האתר.php" >עדכן</button>
       </form>
        </div>
    </div>';
     }

      $product=new product();
       if(isset($_GET['category']))
          {
             $category=$_GET['category'];
             $str= '_';
             $function= $str.$category;
             $function();
          }
     ?>
     <div class="Footer">
      <?php getFooter();?>
    </div>
  </body>
</html>