<?php
/*Authors:Mai Hamduni & Kristina Mushkuv*/
require_once "functions/functions.php";
getrequire();
//session_start();

?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
  <head>
    <?php  getHead();?>
    
    <title>CompStore</title>
  </head>
  <body>
    <div class="row">
      <?php
      getLogo();
      getSearch();
      ProcessLoginOut();
      
      ?>
    </div>
    <div class="row2">
      <?php 
      getNav();?>
    </div>
    <?php 
    if(isset($_POST['history']))
    {
      $orderid=$_POST['history'];

      $db=new dbclass();
      $orderproducts=$db->getOrderProductById($orderid);
       echo  ' <div class="row">
         <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">מוצרים של הזמנה '.$orderid.'</h3>
            <div class="table table-sm" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מספר מוצר</th>
                            <th>שם מוצר </th>
                            <th>תמונה</th>
                            <th>מחיר</th>
                            <th>כמות של מוצר בהזמנה </th>
                            
                        </tr> 
                </thead> ';
      foreach ($orderproducts as $arr) {


        $product=$db->getproductbyid((int)$arr->getProductIDInOrder_Product());       
         echo'<tr> 
            <td>'.$product[0]->getProductId().'</td>
                <td>'.$product[0]->getProductName().'</td>
                <td><img src="'.$product[0]->getimage().'" style="width:50%;"></td>
                <td>'.$product[0]->getUnitPrice().'</td> 
                <td>'.$arr->getQuantityInOrder_Product().'</td>
              </tr>';
    }
  echo
             '</table>
            </div>
        </div>
    </div>
';

      }
      
      
      



    ?>
  
    <div class="Footer">
      <?php getFooter();?>
    </div>
  </body>
</html>