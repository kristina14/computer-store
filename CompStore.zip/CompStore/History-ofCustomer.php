<?php
/*Authors:Mai Hamduni & Kristina Mushkuv*/
require_once "functions/functions.php";
getrequire();
//session_start();

?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
  <head>
    <?php  getHead();?>
    
    <title>CompStore</title>
  </head>
  <body>
    <div class="row">
      <?php
      getLogo();
      getSearch();
      ProcessLoginOut();
      
      ?>
    </div>
    <div class="row2">
      <?php 
      getNav();?>
    </div>
    <?php 
    if(isset($_SESSION['Customer']))
    {
      $customerid=$_SESSION['Customer'];
      $db=new dbclass();
      $orderes=$db->getOrdersofCustomer($customerid);
      
      if(count($orderes)>0)
      {
         echo  ' <div class="row">
        <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">ההזמנות שלי</h3>
        <div class="table" style="margin-bottom:15%;">
                <table class="table"  dir="ltr">
                
                    <thead >      <tr>
                            
                            <th>מספר הזמנה </th>
                            <th>תאריך הזמנה</th>
                            <th>סטטוס</th>
                        </tr> 
                </thead> <tbody>';

              foreach ($orderes as $arr) 
              {
                echo '<tr>
                <td>'.$arr->getOrderId().'</td>
                <td>'.$arr->getOrderDate().'</td>
                <td>'.$arr->getStatus().'</td>
                <td>
                <form method="POST" action="Order-information.php">
                <button type="submit" value="'.$arr->getOrderId().'"class="btn btn-info" name="history">פרטים נוספים</button></form></td>
                </tr>'; 

              }

  echo  '</tbody> </table>
            </div>
        </div>
    </div>
';
      }
    }



    ?>
  
    <div class="Footer">
      <?php getFooter();?>
    </div>
  </body>
</html>