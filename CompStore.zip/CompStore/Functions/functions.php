<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
* This File Conatin's Function's Which Used In Two InterFace
*/
session_start();
function getrequire()
{
	require_once "DataBase/dbClass.php";
	require_once "DataBase/ProductClass.php";
	require_once "DataBase/CustomersClass.php";
	require_once "DataBase/OrderClass.php";
	require_once "DataBase/OrderProduct.php";
	//require_once "fpdf.php";
    //require_once "DataBase/";
}
/*Function to Libraries We Used*/
function getHead(){
	echo '
	<meta charset="utf-8">
<link rel="shortcut icon" href="images/desktop_Computer_PC_24px_520448_easyicon.net.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link href="styles/global.css" rel="stylesheet">
    <script src="scripts/jquery.js"></script>
    <script src="scripts/SearchByPrice.js"></script>
    <link href="styles/Index.css" rel="stylesheet">


';
}
/*Function to Loading The Logo Of The Page*/
function getLogo(){
echo '<div class="col-md-5">
	<div class="logo pull-left" >
		<a href="index.php">
		<img id="logo" style=" hight:8%; width:80%;" class="img-responsive pull-left" alt="link" src="images/weblogo2.png"></a>
	</div>
</div>';
}

/*Function To Loading The Search , Search By Name , AND Search BY Two Price's*/
function getSearch(){
echo '<form method="post" action="Search.php">
      
      <div class="col-md-3 search" dir="ltr" style="margin-top:2%;"">
     	
 	<div class="row">
	<div class="input-group">
		<input type="text" class="form-control mr-sm-5" placeholder="חפש מוצר"  dir="rtl" name="searchbyname">
		<span class="input-group-btn">
			<button class="btn btn-primary" name="search" >
			<span class="glyphicon glyphicon-search">
			</span> חיפוש
			</button>
		</span>
	</div>
	</div>
	  <div class="row" style="margin-right:10%;">
         <div class="col-xs-6 " dir="rtl" >
   					 <label for="ex2">עד</label>
   					 <input type="text" name="price2" class="form-control" placeholder="מחיר">
 					 </div>
      <div class="col-xs-6" dir="rtl">
  				  <label for="ex2">מ</label>
  				  <input type="text" name="price1" class="form-control" placeholder="מחיר">
 				 </div>
 			</div>
</div>
</form>
';
 
}

/*Function to Loading The Footer */
function getFooter(){
echo '<footer class="footer pull-left">
	<a href="###">
	<img alt="link" src="images/facebook_16px_1202552_easyicon.net.ico"></a>
	Designed and developped by Kristina.M and May.H , 2017 For Computer Shop | Follow Us&nbsp;©
	
</footer>';
}

/*Function to Loading New Product*/
function getNewProductTitle(){
echo '        <div class="col-md-12" class="New pull-right">
	<p class="new-text"><a href="index.php"><img src="images/new_24px_1204274_easyicon.net.ico" alt="link"> מוצרים חדשים </a></p>
</div>';
}
/*Function to Loading Category And Sub Category In User Interface,(DataBase)*/
function getNav(){
	$db=new dbClass();
	$arr=$db->getCategories();
	
	echo '<div class="row">
	<div class="col-md-12">
	<ul class="nav nav-justified">';
	
	foreach ($arr as $catergories)
 {
 	$arr2=$db-> getSubCategory($catergories->getCategoryId());
	echo'
	<li class="dropdown ">
	<a href="#" class="dropdown-toggle col-md-12 pull-right" data-toggle="dropdown">'.$catergories->getCategoryName().'<span class="caret"></span></a>

			<ul class="dropdown-menu pagination-centered" style=" ">';
			foreach ($arr2 as $subcategory) {
				echo '<li><a  href="SubCategories.php?category='.$subcategory->getSubCategoryId().'">'.$subcategory->getSubCategoryname().'</a></li>';
			}
		echo '</ul></li>';
}	

	echo '<li "nav-item active"> <a class="nav-link" href="Contant.php"> צור קשר</a> </li> </ul>
	</div></div>';
	

}

/*Function to Limit The Product In Pages(Next - Prev)*/
function getNextPrev()
	{
		
	 if(isset($_GET['Page']))
	 {

	   $db=new dbClass();
	   $arr=$db->getProduct();
	   $size=(int)(count($arr)/9);
	   $Page=$_GET['Page'];

	   if($size+1==$Page)//Last Page
	   {
	   	 $prev=$Page-1;
	      echo ' <br><br><ul class="pagination justify-content-end pull-left" style="margin-top:20%;margin-left:15%; margin-bottom:5%; position:absloute; bottom: 0; ">
  			<li><a href="index.php?Page='.$prev.'">Previous &larr;</a></li>
  			</ul>';
	   }
	   elseif($Page==1)//First Page 
	   {
	   	$next=2;
  		$prev=1;
     	echo ' <ul class="pagination justify-content-end pull-left" style="margin-top:5%; margin-bottom:5%;  margin-left:15%; position:absloute; bottom: 0; ">
   				<li><a href="index.php?Page='.$next.'"> &rarr; Next</a></li>
  				</ul>';
	   }
       else//middle pages 
       {
         $next=$Page+1;
         $prev=$Page-1;
        echo '<ul class="pagination justify-content-end pull-left" style="margin-top:5%; margin-bottom:5%;  margin-left:15%; position:absloute; bottom: 0; ">
  				<li><a href="index.php?Page='.$prev.'">Previous &larr;</a></li>
   				<li><a href="index.php?Page='.$next.'"> &rarr; Next</a></li>
  				</ul>';
  	   }
  	}
  	
	}

	/*Function Loading Products*/
	function loadProducts(int $Page){
	$db=new dbClass();
	$arr=$db->getProduct();
	for($i=1;$i<$Page;$i++);
	if($i!=1)
	{
		$j=($i-1)*9;
	}
	else
	{
		$j=0;
	}
	$count=$j;
	for(;$j<$count+9&&$j<count($arr);$j++)
	{ 

      	echo '
	<form action ="ProductDetails" method="post">
	
	<div class="col-sm-4 col-md-4 portfolio-item">
	
		<img src="' . $arr[$j]->getimage() . '" alt="Screen shot" height="150px" width="150px" />
		<h4 >'.$arr[$j]->getProductName().'</h4>
		<div style="height:80px; width:80%; overflow:hidden;">'.$arr[$j]->getDescription() .'</div>
		<a href="ProductDetails.php?productId='.$arr[$j]->getProductId().'" > למידע נוסף</a>
		<br><br>
	</form>

	</div>';

	}
	}


/*Function Insert New Customer*/
function NewCustomer()
{

	if(isset($_POST['submit']))
	{   $db=new dbclass();
		if($db->getCustomerById($_POST['Customer_id']))
		{
			echo 'לא נוצר משתמש- מספר תעודת זהות זה קיים במערכת';
		}
		else{
	   if(isset($_POST['Customer_id'])&&isset($_POST['Customer_name'])&&isset($_POST['Customer_Lname'])&&isset($_POST['phone'])&&isset($_POST['address'])&&isset($_POST['pass'])&&isset($_POST['gender'])&&isset($_POST['email']))
	   {	
           
	      $cust=new customers();
	      $cust->setCustomerId($_POST['Customer_id']);
	      $cust->setCustomerName($_POST['Customer_name']);
	      $cust->setCustomerLName($_POST['Customer_Lname']);
	      $cust->setCustomerPhone($_POST['phone']);
	      $cust->setCustomerAddress($_POST['address']);
	      $cust->setCustomerpass($_POST['pass']);
	      $cust->setCustomergender($_POST['gender']);
	      $cust->setCustomeremail($_POST['email']);

	      try{
	           $db=new dbClass();
	           $ArrCustomer=$db->InsertCustomer($cust);
	           $db=null;
               echo '<div class="row">
  		             <div class="col-md-12">
                     <img style="width:35%; hight:10%;  margin-right:50%; margin-bottom:5%;" alt="link" src="images/done.png"><div></div>';

 			
       
	         } 

	     catch(PDOEXECPTION $e){
	        echo $ArrCustomer;
	    }
				
	}
}
}

	
}

/*Function to Check Login,Manager Or Customer */
	function getLoginProcess(){
		$db=new dbClass();
		if(isset($_POST['submit'])&&isset($_POST['us_name'])&&isset($_POST['us_pass'])){
			$name = $_POST['us_name'];
			$pass = $_POST['us_pass'];

			$res=$db->getCustomerById($name);
	
			if(count($res)>0)
			{
			 $idcust=$res[0]->getCustomerId();
			
			if(empty($res))
			{
				echo 'משתמש אינו נמצא במערכת';
			}
			else
			{				
				if(password_verify($pass,$res[0]->getCustomerpass())){
					$_SESSION['Customer']=$idcust;
					header('Location: index.php');
					}				
				else
					 echo 'שם משתמש/סיסמה שגויים';
			}
		}
		else
		{
			$res=$db->getEmployeeById($name);
			$idemp=$name;
		     if(empty($res))
			{
				echo 'משתמש אינו נמצא במערכת';
			}
			else
			{
				if(password_verify($pass,$res[0]->getPassManager())){
					$_SESSION['Employee']=$idemp;
					header('Location: Managerindex.php');
				
					}				
				else
					 echo 'שם משתמש/סיסמה שגויים';
			}
			

		}
	}
}


	
	function ProcessLoginOut()
	{
		
		echo '<form method="POST" >';
		if(isset($_SESSION['Customer']))
        {
         echo'<button type="button" class="btn btn-default name="Log" style="margin-top:2%;margin-right:2%;"><a href="logout.php"> <img alt="login" src="images/user_24px_1174223_easyicon.net.ico"> התנתק</a></button>
      ';
         Basket();
         echo '<br><br><a href="History-ofCustomer.php" style="margin-top:1%;margin-right:3%;margin-bottom:2%;">הזמנות שלי/</a>
        <a href="Customer-Profile.php" style="margin-top:1%;margin-bottom:2%;">פרופיל שלי</a> '
         ;
       }
      else
      {
          echo' <button type="button" class="btn btn-default" style="margin-top:2%; margin-right:2%; "><a href="Login.php" > <img alt="login" src="images/user_24px_1174223_easyicon.net.ico"> התחבר/רישום</a> </button>
          ';
          Basket();
      }
      echo '</form>';

      	
	}
	
	function Basket()
	{
		echo '<form method="POST">';
		if(isset($_SESSION['Customer']))
		{
			echo '<button type="button" class="btn btn-default name="Log" style="margin-top:2%;margin-right:2%;"><a href="Shopping-Cart.php"> <img alt="login" src="images/basket_blue_24px_511730_easyicon.net.ico"> סל קניות</a></button>';
       }
       else
       {
       	echo '	<button type="submit" class="btn btn-default" name="AddBasket" style="margin-top:2%;margin-right:2%;"><a href="Login.php">סל קניות</a><img alt="login" src="images/basket_blue_24px_511730_easyicon.net.ico"></button>';
       }
       echo '</form>';


		
	}

	?>