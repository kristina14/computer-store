<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
* This File Conatin's Function's Which Used In Manager InterFace
*/
require_once "functions/functions.php";
/*Function to Loading Category And SubCategory of The Manager Interface*/
function getNavManager()
{

	$db=new dbClass();
	$arr=array();
	 if(isset($_SESSION['Employee']))
       {
           $emp=new employees();
           $db=new dbClass();
           $emp=$db-> getEmployeeById($_SESSION['Employee']);
           if($emp[0]->getManager()=='כן')
            {
	            $arr=$db->getManagerCategories();
	        }
	        else
	        {

	        	$arr=$db->getEmployeeCategories();
	        }
	    }
	

		
	echo '<div class="row">
	
	<div class="col-md-12">
	<ul class="nav nav-justified">';
	
	foreach ($arr as $catergories)
 {
 	
 	$arr2=$db-> getSubManagerCategories((int)$catergories->getmanagercategoriesid());
 	
	echo'
	<li class="dropdown ">
	<a href="#" class="dropdown-toggle col-md-12 pull-right" data-toggle="dropdown">'.$catergories->getmanagercategoriesname().'<span class="caret"></span></a>

			<ul class="dropdown-menu pagination-centered" style=" ">';
			foreach ($arr2 as $subcategory) {

				echo '<li><a  href="'.$catergories->getmanagercategoriesname().'.php?category='.$subcategory->getmanagersubcategoriesId().'">'.$subcategory->getmanagersubcategoriesname().'</a></li>';
			}
		echo '</ul></li>';
}
}
/*Function to Login In Manager Interface*/
function getLoginOutManager()
{

	echo '<form method="POST" >';
	if(isset($_SESSION['Employee']))
        {
         echo'<button type="button" class="btn btn-default btn-lg" name="Log" style="margin-top:1%;margin-right:2%;"><a href="logout.php"> <img alt="login" style="margin-top:2%;" src="images/user_24px_1174223_easyicon.net.ico"> התנתק</a></button>';

       }
      else
      {
          echo' <button type="button" class="btn btn-default btn-lg" style="margin-top:1%;margin-right:2%;"><a href="Login.php"> <img alt="login" style="margin-top:2%;"src="images/user_24px_1174223_easyicon.net.ico"> התחבר/רישום</a> </button> ';
           
      }
      echo '</form>';

}
function getLogoManager(){
echo '<div class="col-md-5">
	<div class="logo pull-left" >
		<a href="Managerindex.php">
		<img id="logo" style=" hight:10%;width:80%;" class="img-responsive pull-left" alt="link" src="images/weblogo2.png"></a>
	</div>
</div>';
}


?>