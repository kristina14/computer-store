$(".slider")
                        
    .slider({ 
        min: 0, 
        max: 1000, 
        range: true, 
        values: [200, 800] 
    })
                        
    .slider("pips", {
        rest: "label"
    })
                        
    .slider("float");