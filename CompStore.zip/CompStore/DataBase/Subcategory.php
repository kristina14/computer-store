<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of SubCategory,There's Param of The DataBase Table 
* Getters AND setters of Params
*/
	class subcategory{
		protected $subcategory_name;
		protected $subcategory_id;
		protected $category_id;

        public function getSubCategoryId()
        {

            return $this->subcategory_id;
        }

        public function getSubCategoryname()
        {

            return $this->subcategory_name;
        }

        public function setCategoryname($subcategory_name)
        {

            $this->subcategory_name=$subcategory_name;
        }

         public function getSubCategoriesID()
        {

            return $this->category_id;
        }
        
        public function setCategoriesID($category_id)
        {

            $this->category_id=$category_id;
        }
	}
?>