<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of Order,There's Param of The DataBase Table 
* Getters AND setters of Params
*/
     class order{

        protected $Order_id;
        protected $Order_date;
        protected $Customer_id;
        protected $Status;
   

public function getOrderId()
{
    return $this->Order_id;
}

public function setOrderId($Order_id)
{
    $this->Order_id=$Order_id;
}


public function getOrderDate()
{
    return $this->Order_date;
}

public function setOrderDate($Order_date)
{
     $this->Order_date=$Order_date;
}

public function getOCustomerId()
{
    return $this->Customer_id;
}

public function setOCustomerId($Customer_id)
{
     $this->Customer_id=$Customer_id;
}
public function getStatus()
{
    return $this->Status;
}
public function setStatus(string $Status)
{
    $this->Status=$Status;
}


}

?>