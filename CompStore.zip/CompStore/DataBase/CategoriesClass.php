<?php
    /*Authors:Mai Hamduni & Kristina Mushkuv
    *class of customer categories*/
    class categories{

        protected $category_id;
        protected $category_name;


        public function getCategoryId()
        {

            return $this->category_id;
        }
        public function setCategoryId($category_id)
        {

            $this->category_id=$category_id;
        }

          public function getCategoryName()
        {

            return $this->category_name;
        }
        public function setCategoryName($category_name)
        {

            $this->category_name=$category_name;
        }



}

?>