<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of Shopping Cart,There's Param of The DataBase Table 
* Getters AND setters of Params
*/

	class shoppingcart{
        protected $Customer_id;
        protected $Quantity;
        protected $Product_id;

        public function getCustomerIdCart()
        {
        	return $this->Customer_id;
        }
        public function setCustomerIdCart($Customer_id)
        {
        	$this->Customer_id=$Customer_id;
        }
        public function getQuantityCart()
        {
        	return $this->Quantity;
        }
        public function setQuantityCart($Quantity)
        {
        	$this->Quantity=$Quantity;
        }
        public function getProductIdCart()
        {
        	return $this->Product_id;
        }
        public function setProductIdCart($Product_id)
        {
        	$this->Product_id=$Product_id;
        }

	}
?>