-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2017 at 07:11 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `std201706db`
--
CREATE DATABASE IF NOT EXISTS `std201706db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `std201706db`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(9) UNSIGNED NOT NULL,
  `category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'מחשבים נייחים'),
(2, 'מחשבים ניידים'),
(3, 'טאבלטים');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `Customer_id` int(9) UNSIGNED NOT NULL,
  `Customer_name` varchar(20) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `city` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `pass` varchar(60) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Customer_id`, `Customer_name`, `phone`, `city`, `address`, `pass`, `gender`, `email`) VALUES
(666666666, 'mai', '0523665478', '', 'kabul', '$2y$10$Pt5OTlZWZ8Ju/Mnp/nzDpeDwp6WVXMzBqTnUHIXOJwxdpWDjM55.C', 'female', 'may.h.95@hotmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `employee_order`
--

CREATE TABLE `employee_order` (
  `Order_id` int(9) UNSIGNED NOT NULL,
  `Employee_id` int(9) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Employee_id` int(9) UNSIGNED NOT NULL,
  `First_name` varchar(20) NOT NULL,
  `Last_name` varchar(20) NOT NULL,
  `Manager` int(1) UNSIGNED NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Employee_id`, `First_name`, `Last_name`, `Manager`, `password`) VALUES
(206232977, 'mai', 'hamdouni', 1, '$2y$10$wFkVQxYoUx7RXKUs5O9g5Osuymy0VccttpL/Dxom2JksJg.yansU6');

-- --------------------------------------------------------

--
-- Table structure for table `managercategories`
--

CREATE TABLE `managercategories` (
  `ManagerCategories_id` int(9) NOT NULL,
  `ManagerCategories_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `managercategories`
--

INSERT INTO `managercategories` (`ManagerCategories_id`, `ManagerCategories_name`) VALUES
(1, 'ניהול האתר'),
(2, 'ניהול מלאי'),
(3, 'ניהול משתמשים'),
(4, 'ניהול עובדים');

-- --------------------------------------------------------

--
-- Table structure for table `managersubcategories`
--

CREATE TABLE `managersubcategories` (
  `ManagerCategories_id` int(9) NOT NULL,
  `ManagerSubCategories_id` int(9) NOT NULL,
  `ManagerSubCategories_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `managersubcategories`
--

INSERT INTO `managersubcategories` (`ManagerCategories_id`, `ManagerSubCategories_id`, `ManagerSubCategories_name`) VALUES
(1, 12, 'הוספת קטגוריה'),
(1, 13, 'מחיקת קטגוריה'),
(1, 14, 'ניהול הזמנות'),
(2, 21, 'הוספת מוצר'),
(2, 22, 'מחיקת מוצר'),
(2, 23, 'עדכון מוצר'),
(2, 24, 'הצגת מלאי החנות'),
(3, 32, 'יצירת קשר עם לקוח'),
(3, 33, 'צפייה בלקוחות'),
(4, 41, 'הוספת עובד'),
(4, 42, 'מחיקת עובד'),
(4, 43, 'צפייה בעובדים');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `Order_id` int(9) UNSIGNED NOT NULL,
  `Order_date` date NOT NULL,
  `Customer_id` int(9) UNSIGNED DEFAULT NULL,
  `Status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`Order_id`, `Order_date`, `Customer_id`, `Status`) VALUES
(21, '2017-08-09', 666666666, 'in process');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `Order_id` int(9) UNSIGNED NOT NULL,
  `product_id` int(9) UNSIGNED NOT NULL,
  `Quantity` int(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`Order_id`, `product_id`, `Quantity`) VALUES
(21, 101, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(9) UNSIGNED NOT NULL,
  `product_name` varchar(40) NOT NULL,
  `description` longtext NOT NULL,
  `unit_price` int(5) UNSIGNED NOT NULL,
  `category_id` int(9) UNSIGNED DEFAULT NULL,
  `image` text NOT NULL,
  `subcategory_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `description`, `unit_price`, `category_id`, `image`, `subcategory_id`) VALUES
(100, 'LG G Pad 8.3', 'LG G Pad 8.3 has the first FHD display on an 8 inch slate. The actual size of the glass is 8.3 inches, carrying a resolution of 1920 x 1200 (WUXGA). A quad-core 1.7GHz Qualcomm Snapdragon 600 processor is under the hood. Using the QPair app, each call and message that appears on a smartphone will also appear on the tablet and simple replies can be send through the G Pad. With the 8.3 inch screen, the LG G Pad 8.3 offers an updated version of QSlide, which lets you choose between three different apps at the same time thanks to the larger glass. With Slide Aside, using a three finger slide allows you to move an open app off to the side of the screen and open a new one. The KnockON feature allows users to turn the slab on or off by tapping on the screen. The LG G Pad 8.3 features 2GB of RAM, with 16GB of native storage. The back and front facing cameras weigh in at 5MP and 1.2MP respectively and a 4600mAh cell keeps the lights on. Android 4.2.2 is pre-installed and the tablet will be available in black and white, weighing 338g.', 1199, 3, 'images/t_1.jpg', 33),
(101, 'מחשב נייד משולב טאבלט Lenovo Miix', 'מחשב נייד משולב טאבלט מבית Lenovo בעל מסך מגע בגודל 10.1 אינטש, מעבד Intel® Atom x5-Z8350 1.44GHz, זיכרון RAM בנפח 2GB, אחסון בנפח 64GB וקישוריות WIFI ו-Bluetooth, בעל מערכת הפעלה Windows 10', 1080, 2, 'images/b_2.jpg', 22),
(102, 'HP Notebook 15-AY025NJ', 'מחשב נייד מבית HP בעל מסך בגודל 15.6 אינטש, מעבד Intel® Core i3-6006U - 2.0GHz, זיכרון פנימי 6GB, כונן קשיח 1TB ומקלדת מלאה', 2599, 2, 'images/b_1.jpg', 12),
(104, ' Desktop Intel Pentium G4560 3.5GHz ', 'סוג:  Intel‏,  מעבד:  Intel Pentium‏,  נפח:  1TB‏,  גודל זכרון:  4GB‏,  ערכת שבבים:  H110', 989, 1, 'images/c_2.png', 11),
(105, ' Desktop Intel Pentium G4560 3.5GHz ', '\n סוג:  Intel‏,  מעבד:  Intel Pentium‏,  נפח:  1TB‏,  גודל זכרון:  4GB‏,  ערכת שבבים:  H110‏,', 1099, 1, 'images/c_1.jpg', 11),
(107, ' Lenovo Miix 320-10 80XF001FIV', 'מחשב נייד משולב טאבלט מבית Lenovo בעל מסך מגע בגודל 10.1 אינטש, מעבד Intel® Atom x5-Z8350 1.44GHz, זיכרון RAM בנפח 2GB, אחסון בנפח 32GB וקישוריות WIFI ו-Bluetooth, בעל מערכת הפעלה Windows 10', 1140, 3, 'images/b_13.jpg', 21),
(108, ' ASUS Vivobook E200HA / L200HA-FD0053T ', 'מחשב נייד מבית Asus בעל מסך 11.6 אינטש, מעבד Intel® Atom Quad Core Z8350 1.44GHz - 1.92GHz, זיכרון פנימי בנפח 2GB, כונן קשיח בנפח 32GB, ללא כונן אופטי\r\n יצרן:  Asus‏,  דגם:  Vivobook E200HA / L200HA‏,  גודל:  11.6\'\'‏,  מעבד:  Intel® Atom‏,  מערכת הפעלה:  Windows 10 Home‏,\r\n', 845, 2, 'images/b_11.jpg', 22),
(109, 'Lenovo IdeaPad 320-15 80XV008HIV', 'מחשב נייד מבית Lenovo בעל מסך 15.6 אינטש, מעבד AMD E2-9000 1.8GHz - 2.20GHz, זיכרון פנימי בנפח 4GB, כונן קשיח בנפח 500GB ללא מערכת הפעלה וללא צורב\r\n יצרן:  Lenovo‏,  דגם:  IdeaPad 320‏,  גודל:  15.6\'\'‏,  מעבד:  AMD E-Series‏,  מערכת הפעלה:  ללא מערכת הפעלה‏', 1090, 2, 'images/m_3.jpg', 21),
(110, 'Lenovo IdeaPad 110S-11 80WG0024IV', 'מחשב נייד מבית Lenovo בעל מסך 11.6 אינטש, מעבד Intel® Pentium N3710 1.6GHz - 2.50GHz, זיכרון פנימי בנפח 4GB, כונן SSD בנפח 32GB מצלמת רשת באיכות HD 720P ומערכת הפעלה Windows 10\r\n יצרן:  Lenovo‏,  דגם:  IdeaPad 110S‏,  גודל:  11.6\'\'‏,  מעבד:  Intel Pentium - N‏,  מערכת הפעלה:  Windows 10 Home‏,', 1140, 2, 'images/m_2.jpg', 21),
(111, 'ASUS Vivobook E200HA / L200HA-FD0053T', 'מחשב נייד מבית Asus בעל מסך 11.6 אינטש, מעבד Intel® Atom Quad Core Z8350 1.44GHz - 1.92GHz, זיכרון פנימי בנפח 2GB, כונן קשיח בנפח 32GB, ללא כונן אופטי\r\n', 845, 1, 'images/b_6.jpg', 12),
(112, 'Lenovo IdeaPad 110S-11 80WG0023IV ', 'מחשב נייד מבית Lenovo בעל מסך 11.6 אינטש, מעבד Intel® Pentium N3710 1.6GHz - 2.50GHz, זיכרון פנימי בנפח 4GB, כונן SSD בנפח 32GB מצלמת רשת באיכות HD 720P ומערכת הפעלה Windows 10\r\n', 1140, 1, 'images/b_7.jpg', 11);

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `Customer_id` int(9) NOT NULL,
  `Product_id` int(9) NOT NULL,
  `Quantity` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `subcategory_name` varchar(60) NOT NULL,
  `subcategory_id` int(30) NOT NULL,
  `category_id` int(9) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcategory_name`, `subcategory_id`, `category_id`) VALUES
('Lenovo', 11, 1),
('Asus', 12, 1),
('Dell', 13, 1),
('Lenovo', 21, 2),
('Asus', 22, 2),
('Dell', 23, 2),
('Hp', 24, 2),
('Apple', 31, 3),
('Samsung', 32, 3),
('LG', 33, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `employee_order`
--
ALTER TABLE `employee_order`
  ADD PRIMARY KEY (`Order_id`,`Employee_id`),
  ADD UNIQUE KEY `Order_id` (`Order_id`),
  ADD UNIQUE KEY `Employee_id` (`Employee_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `managercategories`
--
ALTER TABLE `managercategories`
  ADD PRIMARY KEY (`ManagerCategories_id`);

--
-- Indexes for table `managersubcategories`
--
ALTER TABLE `managersubcategories`
  ADD PRIMARY KEY (`ManagerSubCategories_id`),
  ADD KEY `ManagerCategories_id` (`ManagerCategories_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `Customer_id` (`Customer_id`);

--
-- Indexes for table `order_product`
--
ALTER TABLE `order_product`
  ADD PRIMARY KEY (`Order_id`,`product_id`),
  ADD KEY `Order_id` (`Order_id`,`product_id`),
  ADD KEY `Order_id_2` (`Order_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `subcategory_id` (`subcategory_id`);

--
-- Indexes for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD PRIMARY KEY (`Customer_id`,`Product_id`),
  ADD KEY `Customer_id` (`Customer_id`,`Product_id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`subcategory_id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `Customer_id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=666666667;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `Order_id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee_order`
--
ALTER TABLE `employee_order`
  ADD CONSTRAINT `employee_order_ibfk_1` FOREIGN KEY (`Order_id`) REFERENCES `order` (`Order_id`),
  ADD CONSTRAINT `employee_order_ibfk_2` FOREIGN KEY (`Employee_id`) REFERENCES `employees` (`Employee_id`);

--
-- Constraints for table `managersubcategories`
--
ALTER TABLE `managersubcategories`
  ADD CONSTRAINT `managersubcategories_ibfk_1` FOREIGN KEY (`ManagerCategories_id`) REFERENCES `managercategories` (`ManagerCategories_id`);

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`Customer_id`) REFERENCES `customers` (`Customer_id`);

--
-- Constraints for table `order_product`
--
ALTER TABLE `order_product`
  ADD CONSTRAINT `order_product_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `order_product_ibfk_2` FOREIGN KEY (`Order_id`) REFERENCES `order` (`Order_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategory` (`subcategory_id`);

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
