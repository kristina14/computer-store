<?php
/*Authors: Mai Hamduni & Kristina Mushakov 
*There's Function Contain Query MYSQL
*/
require_once "ProductClass.php";
require_once "CustomersClass.php";
require_once "CategoriesClass.php";
require_once "Subcategory.php";
require_once "OrderClass.php";
require_once "ShoppingCartClass.php";
require_once "ManagerCategoriesClass.php";
require_once "ManagerSubCategoriesClass.php";
require_once "EmployeesClass.php";
require_once "OrderProduct.php";

class dbClass{
    private $host;
    private $db;
    private $charset;
    private $user;
    private $pass;
    private $opt=array(
    PDO::ATTR_ERRMODE    =>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=> PDO::FETCH_ASSOC
);
    private $connection;
    
    public function __construct(string $host="localhost",string $db="STD201706DB",
                               string $charset="utf8",string $user="root",string $pass="")
    {
        $this->host=$host;
        $this->db=$db;
         $this->charset=$charset;
         $this->user=$user;
         $this->pass=$pass;
        
    }
   /*Connect to DataBase*/ 
    private function connect()
    {
        $dsn="mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
        $this->connection= new PDO($dsn,$this->user,$this->pass,$this->opt);
    }
    /*Disconnect*/
    public function disconnect()
    {
        $this->connection=null;
    }
    

    /*This Function,Contain Query (Query Return's All Products)
    * Function Return Array of All Product's
    */
    public function getProduct()
    {
        $this->connect();
        $ProductsArray=array();
        $result=$this->connection->query("SELECT * FROM product  WHERE Status='פעיל'");   
        while($row=$result->fetchObject('product')){
            $ProductsArray[]=$row;
        }
        $this->disconnect();
        return $ProductsArray;
    }
    
    /*Query Return Objects of Customer ,Conatin's All Param of The Customer
    * Function Return Customer Object
    * Add New Customer In DataBase (Insert)
    */
    public function InsertCustomer(customers $cust)
    {
        $this->connect();
        $Insert=$this->connection->prepare("INSERT INTO customers(Customer_id,Customer_name,Customer_Lname,phone,address,pass,gender,email) VALUES (:Customer_id,:Customer_name,:Customer_Lname,:phone,:address,:pass,:gender,:email)"); 
        $result=$Insert->execute([':Customer_id'=>$cust->getCustomerId(),':Customer_name'=>$cust->getCustomerName(),':Customer_Lname'=>$cust->getCustomerLName(),':phone'=>$cust->getCustomerPhone(),':address'=>$cust->getCustomerAddress(),':pass'=>password_hash($cust->getCustomerpass(),PASSWORD_DEFAULT),':gender'=>$cust->getCustomergender(),':email'=>$cust->getCustomeremail()]);

        $this->disconnect();

        return $result;

    }
 

    /*Query Return Array ,Contain All Categories In The Table of DataBase
    * Function Return All Categories
    */
    public function getCategories()
    {
        $this->connect();
        $CategoriesArray=array();
        $result=$this->connection->query("SELECT * FROM categories");   
        while($row=$result->fetchObject('categories')){
            $CategoriesArray[]=$row;
        }
        $this->disconnect();
        return  $CategoriesArray;
    }
  
  

    /*Query Return All SubCategory of Some Category
    *Function Return Array of All SubCategory
    */
    public function getSubCategory(int $parentid)
    {
        $this->connect();
        $SubcategoryArr=array();
        $result=$this->connection->query("SELECT * FROM subcategory WHERE category_id='$parentid'");
        while ($row=$result->fetchObject('subcategory')) {
            $SubcategoryArr[]=$row;
        }
          $this->disconnect();
        return $SubcategoryArr;
    }

    

    /*All SubCategory*/
       public function getAllSubCategory()
    {
        $this->connect();
        $SubcategoryArr=array();
        $result=$this->connection->query("SELECT * FROM subcategory");
        while ($row=$result->fetchObject('subcategory')) {
            $SubcategoryArr[]=$row;
        }
          $this->disconnect();
        return $SubcategoryArr;
    }

    /*Query Return All Information of All Product ,Common Category
    * Function Return's Array of Product's of Some Category
    */
    public function getProductInCategory(int $id)
    {
      $this->connect();
      $categoryarr=array();
      $result=$this->connection->query("SELECT * FROM product WHERE category_id='$id'");
      while ($row=$result->fetchObject('product')) {
        $categoryarr[]=$row;
      }
      $this->disconnect();
      return $categoryarr;
    }
    public function getProductInSubCategory(int $id)
    {
      $this->connect();
      $categoryarr=array();
      $result=$this->connection->query("SELECT * FROM product WHERE subcategory_id='$id'");
      while ($row=$result->fetchObject('product')) {
        $categoryarr[]=$row;
      }
      $this->disconnect();
      return $categoryarr;
    }

    /*Query Return's, All Information of Products ,With Common SubCategory
    *Function Return Array of Products SubCategory
    */

    public function getProductBySubCategories(int $subcategoryid)
    {
        $this->connect();
        $ProductsSubCategoriesArray=array();
        $result=$this->connection->query("SELECT * FROM product WHERE subcategory_id='$subcategoryid' AND Status='פעיל'");
        while($row=$result->fetchObject('product')){
            $ProductsSubCategoriesArray[]=$row;
        }
        $this->disconnect();
        return $ProductsSubCategoriesArray;
    }

    /*Query Return,All Information of One Product
    *Function Return Array Contain All Details of One Product
    */

        function getProductById(int $id)
    {
         $this->connect();
        $ProductsArray=array();
        $result=$this->connection->query("SELECT * FROM product WHERE product_id='$id'");
        while($row=$result->fetchObject('product')){
            $ProductsArray[]=$row;
        }
        $this->disconnect();
        return $ProductsArray;
    
    }

    /* Query Insert(Add) Order
    * Function Return Order Object
    */
    function  InsertOrder(order $ord)
    {
        $this->connect();
          $Insert=$this->connection->prepare("INSERT INTO `order` (Order_id,Order_date,Customer_id,Status) VALUES (NULL,:Order_date,:Customer_id,:Status)");
          $result=$Insert->execute([':Order_date'=>$ord->getOrderDate(),':Customer_id'=>$ord->getOCustomerId(),':Status'=>$ord->getStatus()]);
      $this->disconnect();
     return $result;
    }



    /*Query Return's Latest Order*/
    function GetMaxId()
    {
           $this->connect();
          
           $Insert=$this->connection->query("SELECT MAX(Order_id) as max2 FROM `order`");
           
            $result=$Insert->fetch(PDO::FETCH_ASSOC);
           $this->disconnect();
           return $result['max2'];
    }

    /*Query Return's Object Order_product
    * Insert (Add) Order's
    */
    function InsertOrderProduct(int $orderproudctid,int $productidorderproduct,int $Quantity)
    {
        $this->connect();
        $Insert=$this->connection->prepare("INSERT INTO `order_product` (Order_id,Product_id,Quantity) VALUES(:Order_id,:Product_id,:Quantity)");
        $result=$Insert->execute([':Order_id'=>$orderproudctid,':Product_id'=>$productidorderproduct,':Quantity'=>$Quantity]);

        $this->disconnect();
        return $result;
    }

    /*Query Return's Information of Order's,
    *Function Return Array ,Contain Information of Order's
    */
     public function getOrderProductDetails(int $order_id)
    {
        $this->connect();
        $ProductDetailsOrderArr=array();
        $result=$this->connection->query("SELECT * FROM `order_product` WHERE order_id='$order_id'");
        while ($row=$result->fetchObject('order_product')) {
            $ProductDetailsOrderArr[]=$row;
        }
          $this->disconnect();
        return $ProductDetailsOrderArr;
    }

    /* Query INSERT Shopping Cart
    */
    public function InsertShoppingCart(ShoppingCart $cart)
    {
        $this->connect();
        $Insert=$this->connection->prepare("INSERT INTO shoppingcart (Customer_id,Product_Id,Quantity) VALUES (:Customer_id,:Product_id,:Quantity)");
        $result=$Insert->execute([':Customer_id'=>$cart->getCustomerIdCart(),':Product_id'=>$cart-> getProductIdCart(),':Quantity'=>$cart->getQuantityCart()]);
        $this->disconnect();
        return $result;
    }
    /*UPDATE shopping Cart , Update Qunatity*/

    public function UpdateShoppingCart(int $productIdCart,int $CustomerIdCart,int $QuantityCart)
    {
        $this->connect();

        $Insert=$this->connection->query("UPDATE `shoppingcart` SET Quantity='$QuantityCart' WHERE Customer_id='$CustomerIdCart' AND Product_id='$productIdCart'");

        $this->disconnect();
        return $Insert;
    }
    /*update Quantity of Product*/
    public function UpdateQuantityofProduct(int $id,int $QuantityUpdate)
    {
      $this->connect();
      $result=$this->connection->query("UPDATE `product` SET Quantity='$QuantityUpdate' WHERE product_id='$id'");
      $this->disconnect();
      return $result;
    }

    /*update quantity of order*/
    public function UpdateQuantitytoOrder(int $idorder,int $quantity,int $idproduct)
    {
      $this->connect();
      $result=$this->connection->query("UPDATE `order_product` SET Quantity='$quantity' WHERE Order_id='$idorder' AND product_id='$idproduct' ");
      $this->disconnect();
      return $result;
    }

    /*Query Return All Information of ShoppingCart By Customer*/
    public function getAllDetailsCartProductByCustomerId(int $customer_id)
    {
        $this->connect();
        $shoppingcartArr=array();
        $result=$this->connection->query("SELECT * FROM shoppingcart WHERE Customer_id='$customer_id'");
     while ($row=$result->fetchObject('shoppingcart')) {
            $shoppingcartArr[]=$row;
        }
        $this->disconnect();
        return $shoppingcartArr;

    }

    /*Query Return All Products By Product Name ,
    *Function Search All Products By Name's
    */
   public function SearchByNameProduct(string $searchbyname)
   {
        $this->connect();
        $searchproductArr=array();     
    $result=$this->connection->query("SELECT * FROM product WHERE product_name LIKE '%$searchbyname%'");
        while ($row=$result->fetchObject('product')){
        $searchproductArr[]=$row;
        }
        $this->disconnect();
        return $searchproductArr;
   } 

   /*Query Return All Products By Product Price
    *Function Search All Products, Between Two Prices's
   */
   public function SerachByPriceProduct(int $price1,int $price2)
   {
        $this->connect();
        $searchPriceproductArr=array();
        $result=$this->connection->query("SELECT * FROM product where unit_price BETWEEN '$price1' AND '$price2' ORDER BY unit_price ASC");
                while ($row=$result->fetchObject('product')){
         
        $searchPriceproductArr[]=$row;
           
        }
        $this->disconnect();
        return $searchPriceproductArr; 

   }


   /* Query Return All Product By Name And Between Two Price's
   *  Function Search By Name & Two Price's
   */
   public function SearchPriceAndName(string $name,int $price1,int $price2)
   {
        $this->connect();
        $searcharr=array();
        $result=$this->connection->query("SELECT * FROM product where unit_price BETWEEN '$price1' AND '$price2' AND product_name LIKE '%$name%' ORDER BY `unit_price` ASC");
        while ($row=$result->fetchObject('product')) {
            $searcharr[]=$row;
        }
      
        $this->disconnect();
        return $searcharr;

   }

   /*Query Delete */
   public function DeleteProductsShoppingCart(int $id)
   {
        $this->connect();
        $this->connection->query("DELETE  FROM `shoppingcart` WHERE Customer_id='$id'");
        $this->disconnect();
        return;
   }
   public function DeleteProductsShoppingCart0(int $productId,int $custid)
   {
    $this->connect();
    $this->connection->query("DELETE FROM `shoppingcart` WHERE Customer_id='$custid' AND product_id='$productId'");
    $this->disconnect();
    return;
   }

   /*Insert New Category*/
   public function AddNewCategories(categories $cat)
   {
    $this->connect();
    $Insert=$this->connection->prepare("INSERT INTO `categories` (category_name) VALUES (:category_name)");
    $result=$Insert->execute([':category_name'=>$cat->getCategoryName()]);
    $this->disconnect();
    return $result;
   }

   public function getQuantityByProductID(int $id)
   {
      $this->connect();
      $result=$this->connection->query("SELECT Quantity FROM `shoppingcart` WHERE $Product_id='$id'");
      $this->disconnect();
      return $result;
   }

      public function getQuantityByProductIDInOrder(int $id)
   {
      $this->connect();
      $result=$this->connection->query("SELECT Quantity FROM `order_product` WHERE $product_id='$id'");
      $this->disconnect();
      return $result;
   }
   public function DeleteOrderProduct(int $id)
   {
    $this->connect();
    $result=$this->connection->query("DELETE  FROM `order_product` WHERE Order_id='$id'");
    $this->disconnect();
    return;
   }
   public function DeleteEmployeeOrder(int $id)
   {
    $this->connect();
    $result=$this->connection->query("DELETE  FROM `employee_order` WHERE Order_id='$id'");
    $this->disconnect();
    return;
   }
   public function DeleteCustomer(int $id)
   {
    $this->connect();
    $result=$this->connection->query("DELETE  FROM `customers` WHERE Customer_id='$id'");
    $this->disconnect();
    return;
   }
   public function UpdateShoppingCartByCustomerIDANDproduct(int $custid,int $Quantity,int $productId)
   {
    $this->connect();
    $result=$this->connection->query("UPDATE `shoppingcart` SET `Quantity`='$Quantity' WHERE Customer_id='$custid' AND product_id='$productId' ");
    $this->disconnect();
    return $result;

   }






   /*------------------Employe Interface-------------------------------------------*/

    /*Query Return's All Categories But to Manager Interface*/
     public function getManagerCategories()
    {
        $this->connect();
        $managercategoriesarr=array();
        $result=$this->connection->query("SELECT * FROM managercategories");
        while($row=$result->fetchObject('managercategories')){
            $managercategoriesarr[]=$row;
        }
        $this->disconnect();
        return $managercategoriesarr;
    }
    
    /*Query Return's employee categories*/
    public function getEmployeeCategories()
    {
      $this->connect();
      $managercategoryarr=array();
      $result=$this->connection->query("SELECT * FROM managercategories WHERE manager='לא'");
      while ($row=$result->fetchObject('managercategories')) {
        $managercategoryarr[]=$row;
      }
      $this->disconnect();
      return $managercategoryarr;
    }

    /*Query Return's SubCategory of Some Category ,In Manager Interface*/
    public function getSubManagerCategories(int $parentidmanager)
    {
        $this->connect();
        $subcategoriesmanager=array();
        $result=$this->connection->query("SELECT * FROM managersubcategories WHERE managercategories_id='$parentidmanager'");
        while ($row=$result->fetchObject('managersubcategories')) {
           $subcategoriesmanager[]=$row;
        }
        $this->disconnect();
        return $subcategoriesmanager;
    }

    /*Query Return's All Information of Customer By ID*/
     public function getCustomerById(int $id)
    {

        $this->connect();
        $customermanager=array();
        $result=$this->connection->query("SELECT * FROM customers WHERE Customer_id='$id'");
        while ($row=$result->fetchObject('customers')) {
            $customermanager[]=$row;
        }
        $this->disconnect();
        return $customermanager;

    }

    /*Query Return All Customer's*/
    public function getCustomers()
    {
        $this->connect();
        $customer=array();
        $result=$this->connection->query("SELECT * FROM customers ");
        while($row=$result->fetchObject('customers'))
        {
            $customer[]=$row;
        }
        $this->disconnect();
        return $customer;
    }

    /*Query Delete Categories Of Customer*/

   public function DeleteCategoriesCustomer(int $id)
   {
    $this->connect();
    $this->connection->query("DELETE FROM `categories` WHERE category_id='$id'");
    $this->disconnect();
    return;
   }

public function getAllOrderDetails()
   {
    $this->connect();
    $orderdetails=array();
    $result=$this->connection->query("SELECT * FROM `order` ");
    while ($row=$result->fetchObject('order')) {
     $orderdetails[]=$row;   
    }
    $this->disconnect();
    return $orderdetails;
   }


   /*Query Return's In Status In Process Details of Order*/
   public function getOrderDetails()
   {
    $this->connect();
    $orderdetails=array();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Status='In Process'");
    while ($row=$result->fetchObject('order')) {
     $orderdetails[]=$row;   
    }
    $this->disconnect();
    return $orderdetails;
   }

    public function getOrderDetailsDONE()
   {
    $this->connect();
    $orderdetails=array();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Status='End Process'");
    while ($row=$result->fetchObject('order')) {
     $orderdetails[]=$row;   
    }
    $this->disconnect();
    return $orderdetails;
   }
   /*Query to Insert Product (Add Product) In Manager Interface*/
   public function InsertProductManager(product $pro)
   {
      $this->connect();
      $status='פעיל';
      $Insert=$this->connection->prepare("INSERT INTO product (product_name,unit_price,category_id,image,description,subcategory_id,Quantity,Status)VALUES (:product_name,:unit_price,:category_id,:image,:description,:subcategory_id,:Quantity,:Status)");
      $result=$Insert->execute([':product_name'=>$pro->getProductName(),':unit_price'=>$pro->getUnitPrice(),':category_id'=>$pro->getCategoryId(),':image'=>$pro->getimage(),':description'=>$pro->getDescription(),':subcategory_id'=>$pro->getsubCategoryId(),':Quantity'=>$pro->getQuantityProduct(),':Status'=>$status]);
      $this->disconnect();
      return $result;
   }
   /*Query UPDATE Product In Manager Interface*/
   public function UpdateProducts(product $pro)
   {
       
       $this->connect();
       echo '<pre>';
       print_r($pro);
       echo '</pre>';
       $productId=$pro->getProductId();
       $productName=$pro->getProductName();
       $productPrice=$pro->getUnitPrice();
       $productDescription=$pro->getDescription();
      $Insert=$this->connection->query("UPDATE `product` SET product_name='$productName',unit_price='$productPrice',description='$productDescription' WHERE product_id='$productId'");
        $this->disconnect();
        return $Insert;
   }
   /*Query UPDATE Customer In Manager Interface*/
   public function UpdateCustomer(customers $cust)
   {
    $this->connect();
    $customerID=$cust->getCustomerId();
    $customerName=$cust->getCustomerName();
    $customerLname=$cust->getCustomerLName();
    $customerPhone=$cust->getCustomerPhone();
    $customeremail=$cust->getCustomeremail();
    $customerAddress=$cust->getCustomerAddress();

    $Insert=$this->connection->query("UPDATE `customers` SET Customer_name='$customerName',phone='$customerPhone',Customer_Lname='$customerLname',email='$customeremail',address='$customerAddress' WHERE Customer_id='$customerID'");
    $this->disconnect();
    return $Insert;

   }

   /*Query Return's All Employees*/
   public function getEmployeeDetails()
   { 
    $this->connect();
    $employeeArr=array();
    $result=$this->connection->query("SELECT * FROM employees");
    while($row=$result->fetchObject('employees'))
    {
        $employeeArr[]=$row;
    }
    $this->disconnect();
    return $employeeArr;

    }

    /*Query Return All Information of Employee By ID*/
   public function getEmployeeById(int $id)
   {
    $employeearr=array();
    $this->connect();
    $result=$this->connection->query("SELECT * FROM employees WHERE Employee_id='$id'");
    while($row=$result->fetchObject('employees'))
    {
        $employeearr[]=$row;
    }
    $this->disconnect();
    return $employeearr;

   }

   /*Query Insert (Add) Employee*/
   public function InsertEmployee(employees $emp)
   {
      
      $pass=password_hash($emp->getPassManager(),PASSWORD_DEFAULT);
    $this->connect();
    $Insert=$this->connection->prepare("INSERT INTO employees (Employee_id,First_name,Last_name,password,manager) VALUES (:Employee_id,:First_name,:Last_name,:password,:manager)");
    $result=$Insert->execute([':Employee_id'=>$emp->getEmployeesId(),':First_name'=>$emp->getFirstName(),':Last_name'=>$emp->getLastName(),':password'=>$pass,':manager'=>$emp->getManager()]);
    $this->disconnect();
    return $result;
   }


   /*Query Return's Category By Name*/
   public function getCategoriesByName(string $str)
   {
    $this->connect();
    $arr=array();
    $result=$this->connection->query("SELECT * FROM categories WHERE category_name='$str' ");
    while($row=$result->fetchObject('categories')){
      $arr[]=$row;
    }
    
    $this->disconnect();
    return $arr;

   }

   /*Query Delete Product*/
   public function DeleteProduct(int $id)
   {
      $this->connect();
      $result=$this->connection->query("UPDATE `product` SET Status='לא פעיל' WHERE product_id='$id'");
      $this->disconnect();
      return;
   }
   /*Query Delete Employee*/
   public function DeleteEmployee(int $id)
   {
    $this->connect();
    $result=$this->connection->query("DELETE FROM `employees` WHERE Employee_id='$id'");
    $this->disconnect();
    return;
   }
   /*Query To UPDATE  Status*/
   public function SetStatusYes(string $str,int $id)
   {  
    $this->connect();

    $result=$this->connection->query("UPDATE `order` SET Status='$str' WHERE Order_id='$id'");
    $this->disconnect();
   
    return $result;
   }

   public function returnOrdertoProcess(int $id)
   {
    $this->connect();
     $result=$this->connection->query("UPDATE `order` SET Status='In process' WHERE Order_id='$id' AND Status='DONE'");
    $this->disconnect();
   
    return $result;
   }

   /*Query to Insert Employee_Order*/
   public function AddOrderEmployee(int $orderid,int $employeeid)
   {
    $this->connect();
    $Insert=$this->connection->prepare("INSERT INTO `employee_order` (Order_id,Employee_id) VALUES (:Order_id,:Employee_id)");
    $result=$Insert->execute([':Order_id'=>$orderid,':Employee_id'=>$employeeid]);
    $this->disconnect();
    return $result;
   }
   /*Query Return's Object , Check If The Product_Id In Order*/
   public function CheckiFproductInOrder(int $id)
   {
    $this->connect();
    $productorder=array();
    $result=$this->connection->query("SELECT Order_id FROM `order_product`  WHERE product_id='$id'");
    
    while($row=$result->fetchObject('order'))
    {
      $productorder[]=$row;
    }

    $this->disconnect();
    return $productorder;
   }
   /*Return iF Status By Order Id*/
   public function returnorderstatus(int $id)
   {
    $this->connect();
    $orderstatus=array();
    $result=$this->connection->query("SELECT Status FROM `order` WHERE Order_id='$id' and Status <>'End Process'");
     while ($row=$result->fetchObject('order')) {
        $orderstatus[]=$row;
      }
      $this->disconnect();
      return $orderstatus;
   }


   /*Add SubCategory In User InterFace By Manager*/
   public function InsertSubCategory(subcategory $cat)
   {
    $this->connect();
    $Insert=$this->connection->prepare("INSERT INTO`subcategory` (subcategory_name,category_id) VALUES(:subcategory_name,:category_id)");
    $result=$Insert->execute([':subcategory_name'=>$cat->getSubCategoryname(),':category_id'=>$cat->getSubCategoriesID()]);
    $this->disconnect();
    return $result;
   }




   /*Query Delete The SubCategory By number of Category*/
   public function DeleteSubCategoryByCategory(int $categoryId){
    $this->connect();
    $this->connection->query("DELETE FROM  `subcategory` WHERE subcategory_id='$categoryId'");
    $this->disconnect();
    return;
   }

   /*Query Rteurn's Order By Employee*/
   public function getEmployeeOrder(int $employeeid)
   {
    $orderemplpoyee=array();
    $this->connect();
    $result=$this->connection->query("SELECT Order_id FROM `employee_order` WHERE Employee_id='$employeeid'");
      while ($row=$result->fetchObject('order')) {
        $orderemplpoyee[]=$row;
      }
      $this->disconnect();
      return $orderemplpoyee;
   }
   /*Query Return's all information order by employee*/
     public function getEmployeeOrderinfo(int $employeeid)
   {
    $orderemplpoyee=array();
    $this->connect();
    $result=$this->connection->query("SELECT * FROM `employee_order` WHERE Employee_id='$employeeid'");
      while ($row=$result->fetchObject('order')) {
        $orderemplpoyee[]=$row;
      }
      $this->disconnect();
      return $orderemplpoyee;
   }

   /*Query Return's Order of Customer*/
   public function getOrderofCustomer(int $custid)
   {
      $ordercust=array();
      $this->connect();
      $result=$this->connection->query("SELECT Order_id FROM `order` WHERE Customer_id='$custid' AND Status<>'End Process' ");
      while($row=$result->fetchObject('order'))
      {
        $ordercust[]=$row;
      }
      $this->disconnect();
      return $ordercust;
   }
   public function getOrderProductById(int $id)
   {
    $orderproduct=array();
    $this->connect();
    $result=$this->connection->query("SELECT * From `order_product` WHERE Order_id='$id'");
    while($row=$result->fetchObject('order_product'))
    {
      $orderproduct[]=$row;
    }
    $this->disconnect();
    return $orderproduct;
   }


    public function getAllOrderofCustomer(int $custid)
   {
      $ordercust=array();
      $this->connect();
      $result=$this->connection->query("SELECT Order_id FROM `order` WHERE Customer_id='$custid'");
      while($row=$result->fetchObject('order'))
      {
        $ordercust[]=$row;
      }
      $this->disconnect();
      return $ordercust;
   }
   public function getOrdersofCustomer(int $custid)
   {
    $ordercust=array();
      $this->connect();
      $result=$this->connection->query("SELECT * FROM `order` WHERE Customer_id='$custid'");
      while($row=$result->fetchObject('order'))
      {
        $ordercust[]=$row;
      }
      $this->disconnect();
      return $ordercust;
   }

   /*Query Delete The Order By Employee Id*/
   public function DeleteOrderByEmployee(int $employeeid)
   {
    $this->connect();
    $this->connection->query("DELETE  FROM `employee_order` WHERE Employee_id='$employeeid'");
    $this->disconnect();
    return ;
   }
   /*Query Delete The Order By Customer ID*/
   public function DeleteOrderByCustomer(int $custid)
   {
    $this->connect();
    $this->connection->query("DELETE FROM `order` WHERE Customer_id='$custid'");
    $this->disconnect();
    return;
   }

   public function getOrderById(int $id)
   {
    $this->connect();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Order_id='$id'");
    $orderemployee=array();
    while ($row=$result->fetchObject('order')) {
      $orderemployee[]=$row;
    }
    $this->disconnect();
    return $orderemployee;
   }

   public function getOrderNotEndById(int $id)
   {
    $this->connect();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Order_id='$id' AND Status<>'End Process' ");
    $orderemployee=array();
    while ($row=$result->fetchObject('order')) {
      $orderemployee[]=$row;
    }
    $this->disconnect();
    return $orderemployee;
   }


   public function getOrderStatusById(int $id)
   {
    $this->connect();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Status<>'End Process'");
    $orderemployee=array();
    while ($row=$result->fetchObject('order')) {
      $orderemployee[]=$row;
    }
    $this->disconnect();
    return $orderemployee;
   }
   /*get Order Id By Customer Id*/
   public Function getorderIdByCustomerID(int $id)
   {
    $this->connect();
    $customerorderId=array();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Customer_id='$id'");
    while($row=$result->fetchObject('order'))
      {
        $customerorderId[]=$row;
      }
      $this->disconnect();
      return $customerorderId;
   }
   /*get order by employee id*/
   public function  getorderByEmployee(int $id)
   {

     $this->connect();
    $result=$this->connection->query("SELECT * FROM `employee_order` WHERE Employee_id='$id'");
    $orderemployee=array();
    while ($row=$result->fetchObject('order')) {
      $orderemployee[]=$row;
    }
    $this->disconnect();
    return $orderemployee;
   }


   /**********Reports**********/
   public function ProductOutOfStock()
   {
    $this->connect();
    $result=$this->connection->query("SELECT * FROM product WHERE `Quantity`=0");
    $QuantityArr=array();
    while($row=$result->fetchObject('product'))
    {
      $QuantityArr[]=$row;
    }
    $this->disconnect();
    return $QuantityArr;
   }
   //Query to return Employee by order
   public function EmployeeByOrder(int $id)
   {
    $this->connect();
    $result=$this->connection->query("SELECT Employee_id FROM `Employee_Order` WHERE Order_id='$id'");
    $employeeorder=array();
    while($row=$result->fetchObject('employees'))
    {
      $employeeorder[]=$row;
    }
    $this->disconnect();
    return $employeeorder;
   }
   //Query to Return All Product in orders
  public function ProductOrder()
  {
      $this->connect();
      $result=$this->connection->query("SELECT DISTINCT  product_id FROM `order_product`");
      $ProductOutOfStockArr=array();
      while($row=$result->fetchObject('order_product'))
      {
        $ProductOutOfStockArr[]=$row;
      }
      $this->disconnect();
      return $ProductOutOfStockArr;

  }


  //Query to Return Quantity of Product
  public function QuantityofProduct(int $id)
  {
    $this->connect();
    $result=$this->connection->query("SELECT `Quantity` FROM order_product WHERE `product_id`='$id'");
    $Quantity=array();
    while($row=$result->fetchObject('order_product'))
    {
      $Quantity[]=$row;
    }
    $this->disconnect();
    return $Quantity;
  }
  //Query to Orders Between Two Dates
  public function OrdertBetweenDate($date1,$date2)
  {
    $this->connect();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Order_date BETWEEN '$date1' AND '$date2' ORDER BY Order_date DESC");
    $orderdate=array();
    while($row=$result->fetchObject('order'))
    {
      $orderdate[]=$row;
    }
    $this->disconnect();
    return $orderdate;
  }
  //Query to return orders not end process
  public function NotEndProcess()
  {
    $this->connect();
    $result=$this->connection->query("SELECT * FROM `order` WHERE Status<>'End Process'");
    $endprocess=array();
    while($row=$result->fetchObject('order'))
    {
      $endprocess[]=$row;
    }
    $this->disconnect();
    return $endprocess;
  }
  /*UPDATE STATUS BY MANAGER*/
  public function UPDATEStatusByManager(int $orderid,$status)
  {
    $this->connect();
    $result=$this->connection->query("UPDATE `order` SET Status='$status' WHERE Order_id='$orderid'");
    $this->disconnect();
    return $result;
  }


}   
?>