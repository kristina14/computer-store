<?php
    /*Authors:Mai Hamduni & Kristina Mushkuv
*Class of Employees,There's Param of The DataBase Table 
* Getters AND setters of Params
*/
 class employees{
        protected $Employee_id;
        protected $First_name;
        protected $Last_name;
        protected $password;
        protected $Manager;
   

public function getEmployeesId()
{
    return $this->Employee_id;
}

public function setEmployeesId($Employee_id)
{
   $this->Employee_id=$Employee_id;
}


public function getFirstName()
{
    return $this->First_name;
}

public function setFirstName($First_name)
{
     $this->First_name=$First_name;
}

public function getLastName()
{
    return $this->Last_name;
}

public function setLastName($Last_name)
{
     $this->Last_name=$Last_name;
}

public function getPassManager()
{
    return $this->password;
}
public function setPassManager($password)
{
    $this->password=$password;
}
public function getManager()
{
  return $this->Manager;
}
public function setManager($manager)
{
  $this->Manager=$manager;
}


}

?>