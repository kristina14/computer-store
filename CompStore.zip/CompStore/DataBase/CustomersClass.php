<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of Customers,There's Param of The DataBase Table 
* Getters AND setters of Params
*/
   class customers{

        protected $Customer_id;
        protected $Customer_name;
        protected $phone;
        protected $city;
        protected $address;
        protected $pass;
        protected $gender;
        protected $email;
        protected $Customer_Lname;
        
        public function getCustomerId()
        {
            return $this->Customer_id;
        }
        public function setCustomerId($Customer_id)
        {
            $this->Customer_id=$Customer_id;
        }
          public function getCustomerName()
        {
            return $this->Customer_name;
        }
          public function getCustomerLName()
        {
            return $this->Customer_Lname;
        }
        public function setCustomerName($Customer_name)
        {
            $this->Customer_name=$Customer_name;
        }
        public function setCustomerLName($Customer_Lname)
        {
            $this->Customer_Lname=$Customer_Lname;
        }
          public function getCustomerPhone()
        {
            return $this->phone;
        }
        public function setCustomerPhone($phone)
        {
            $this->phone=$phone;
        }
        public function getCustomerCity()
        {
            return $this->city;
        }
        public function setCustomerCity($city)
        {
            $this->city=$city;
        }
          public function getCustomerAddress()
        {
            return $this->address;
        }
        public function setCustomerAddress($address)
        {
            $this->address=$address;
        }
            public function getCustomerpass()
        {
            return $this->pass;
        }
        public function setCustomerpass($pass)
        {
            $this->pass=$pass;
        }
          public function getCustomergender()
        {
            return $this->gender;
        }
        public function setCustomergender($gender)
        {
            $this->gender=$gender;
        }
              public function getCustomeremail()
        {
            return $this->email;
        }
        public function setCustomeremail($email)
        {
            $this->email=$email;
        }
        
}


?>