<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of Manager Categories (In Manager Interface),There's Param of The DataBase Table 
* Getters AND setters of Params
*/
 class managercategories{

		protected $ManagerCategories_id;
		protected $ManagerCategories_name;

		public function getmanagercategoriesid()
		{
			return $this->ManagerCategories_id;
		}
		public function setmanagercategoriesid($ManagerCategories_id)
		{
			$this->ManagerCategories_id=$ManagerCategories_id;
		}


		public function getmanagercategoriesname()
		{
			return $this->ManagerCategories_name;
		}
		public function setmanagercategoriesname($ManagerCategories_name)
		{
			$this->ManagerCategories_name=$ManagerCategories_name;
		}
}


?>