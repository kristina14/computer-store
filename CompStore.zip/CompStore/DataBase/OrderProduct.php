<?php
	class order_product{
		protected $Order_id;
		protected $product_id;
		protected $Quantity;

		public function getOrderIDInOrder_Product()
		{
			return $this->Order_id;
		}
		public function setOrderIDInOrder_Product($Order_id)
		{
			$this->Order_id=$Order_id;
		}
		public function getProductIDInOrder_Product()
		{
			return $this->product_id;
		}
		public function setProductIDInOrder_Product($product_id)
		{
			 $this->product_id=$product_id;
		}
		public function getQuantityInOrder_Product()
		{
			return $this->Quantity;
		}
		public function setQuantityInOrder_Product($Quantity)
		{
			$this->Quantity=$Quantity;
		}

	}


?>