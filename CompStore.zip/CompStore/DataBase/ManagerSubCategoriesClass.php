<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of SubCategory In Manager Interface,There's Param of The DataBase Table 
* Getters AND setters of Params
*/
 class managersubcategories{

		protected $ManagerCategories_id;
		protected $ManagerSubCategories_name;
		protected $ManagerSubCategories_id;

		public function getmanagercategoriesid()
		{
			return $this->ManagerCategories_id;
		}
		public function setmanagercategoriesid($ManagerCategories_id)
		{
			$this->ManagerCategories_id=$ManagerCategories_id;
		}


		public function getmanagersubcategoriesname()
		{
			return $this->ManagerSubCategories_name;
		}
		public function setmanagersubcategoriesname($ManagerSubCategories_name)
		{
			$this->ManagerSubCategories_name=$ManagerSubCategories_name;
		}

		public function getManagerSubCategoriesId()
		{
			return $this->ManagerSubCategories_id;
		}
		public function setManagerSubCategoriesId($ManagerSubCategories_id)
		{
			$this->ManagerSubCategories_id=$ManagerSubCategories_id;
		}

}


?>