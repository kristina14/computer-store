<?php
/*Authors:Mai Hamduni & Kristina Mushkuv
*Class of Product,There's Param of The DataBase Table 
* Getters AND setters of Params
*/
   class product{
        protected $product_id;
        protected $product_name;
        protected $unit_price;
        protected $category_id;
        protected $image;
        protected $description;
        protected $subcategory_id;
        protected $subcategory_name;
        protected $Quantity;
        protected $Status;
        
        

        public function getProductId()
        {
            return $this->product_id;
        }
        public function setProductId($product_id)
        {
            $this->product_id=$product_id;
        }

            public function getProductName()
        {
            return $this->product_name;
        }
        public function setProductName($product_name)
        {
            $this->product_name=$product_name;
        }
            public function getUnitPrice()
        {
            return $this->unit_price;
        }
        public function setUnitPrice($unit_price)
        {
            $this->unit_price=$unit_price;
        }
             public function getCategoryId()
        {
            return $this->category_id;
        }
        public function setCategoryId($category_id)
        {
            $this->category_id=$category_id;
        }
    
       public function getimage()
        {
            return $this->image;
        }
        public function setimage($image)
        {
            $this->image=$image;
        }
         public function getDescription()
        {
            return $this->description;
        }
        public function setdescription($description)
        {
            $this->description=$description;
        }
        public function getsubCategoryId()
        {
            return $this->subcategory_id;
        }
        public function getsubCategoryName()
        {
            return $this->subcategory_name;
        }
        public function setsubCategoryId($subcategory_id)
        {
            $this->subcategory_id=$subcategory_id;
        }
        public function getQuantityProduct()
        {
            return $this->Quantity;
        }
        public function setQuantityProduct($Quantity)
        {
            $this->Quantity=$Quantity;
        }
        public function getProductStatus()
        {
            return $this->Status;
        }
        

    }


?>