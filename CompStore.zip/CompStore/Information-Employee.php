<?php
/*Authors:Mai Hamduni & Kristina Mushkuv*/
require_once "functions/functions.php";
require_once "functions/FunctionsManager.php";
getrequire();
//session_start();

?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
  <head>
    <?php  getHead();?>
    
    <title>CompStore</title>
  </head>
  <body>
    <div class="row">
      <?php
      getLogo();
      getLoginOutManager();
      getNavManager();//The Category And SubCategory of The Manager Interface
      ?>
    </div>
   <?php 
      if(isset($_POST['Moreinfo']))
      {
         $employeeid=$_POST['Moreinfo'];
         $db=new dbclass();
        $Employeeorder=$db->getEmployeeOrder($employeeid);
        echo' <div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
                <h2 style="margin-top: 20%;margin-bottom:10%"> הזמנות בטיפולו של עובד: '.$employeeid.'</h2>
                  <table class="table"  dir="ltr">
                
                    <thead >   
                    <tr>
                            <th>מספר הזמנה  </th>
                            <th>תאריך הזמנה</th>
                            <th>סטטוס</th>
                    </tr> 
                </thead>';
          $order=array();
        foreach ($Employeeorder as $arr)
        {
          $id=(int)$arr->getOrderId();
          $order=$db->getOrderById($id);


          echo '<tr>';
          echo'<td>'.$order[0]->getOrderId().'</td>
                    <td>'.$order[0]->getOrderDate().'</td>
                    <td>'.$order[0]->getStatus().'</td>
                    </tr>';

        }
           echo  '</table>
            </div>
        </div>
    </div>
          ';

      }







  ?>
    <div class="Footer">
      <?php getFooter();?>
    </div>
  </body>
</html>