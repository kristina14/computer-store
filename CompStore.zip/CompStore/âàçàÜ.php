<?php
/*Authors:Mai Hamduni & Kristina Mushkuv*/
require_once "functions/functions.php";
require_once "functions/FunctionsManager.php";
getrequire();
//session_start();

?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
  <head>
    <?php  getHead();/*Loading Libraries*/?>
    
    <title>CompStore</title>
  </head>
  <body>
    <div class="row">
      <?php
      getLogoManager();/*Loading Logo*/
      getLoginOutManager();/*Login Manager */
   
      getNavManager();
      ?>
    </div>
      <?php

      //function of out of stock products 
      function _61()
      {   $db=new dbClass();
          $productarr=array();
          $productarr=$db->ProductOutOfStock();//using query 
         $str="מוצרים שאזלו מהמלאי";
          tabledisieng($str);
          $productDetails=array();
          //put data in table      
        foreach ($productarr as $arr) {
          $productDetails=$db->getProductById($arr->getProductId());
          foreach ($productDetails as $product) {
            $productName=$product->getProductName();
          }
         echo'<tr> 
            <td>'.$arr->getProductId().'</td>
                <td>'.$productName.'</td>
                <td><img src="'.$arr->getimage().'"style="width:40%; hight:30%; margin-top:1%;"></td>
                <td " style="width:20%; hight:40%;">'.$arr->getDescription().' </td> 
                <td>'.$arr->getUnitPrice().'</td> 
                <td>'.$arr->getCategoryId().'</td>
                <td>'.$arr->getsubCategoryId().'</td>
                <td>'.$arr->getQuantityProduct().'</td>
              </tr>';
    }
     echo '<form method="POST">
    <button type="submit" name="ReportOutofStock" class="btn btn-primary">להוריד דוח</button>
    </form>';
    if(isset($_POST['ReportOutofStock']))
    {
      $file=fopen('Reports/מצרים שאזלו ממלאי .csv','w');
      $title=array(array('מספר מוצר','שם מוצר','מחיר','קטגוריה','תת קטגוריה','כמות'));
     
      fputs($file, chr(0xFF) . chr(0xFE));
    foreach ($title as $fields) {
    $out = '';
    foreach ($fields as $k => $v){
        $fields[$k] = mb_convert_encoding($v, 'UTF-16LE', 'UTF-8');        
    }
    $out = implode(chr(0x09).chr(0x00), $fields);
    fputs($file, $out.chr(0x0A).chr(0x00));
  }

  foreach ($productarr as $arr) {
    $out='';
    $arr2=array();
     $productDetails=$db->getProductById($arr->getProductId());
     foreach ($productDetails as $product) {
    $arr2[0]=mb_convert_encoding($product->getProductId(), 'UTF-16LE', 'UTF-8');
    $arr2[1]=mb_convert_encoding($product->getProductName(), 'UTF-16LE', 'UTF-8');
    $arr2[2]=mb_convert_encoding($product->getUnitPrice(), 'UTF-16LE', 'UTF-8');
    $arr2[3]=mb_convert_encoding($product->getCategoryId(), 'UTF-16LE', 'UTF-8');
    $arr2[4]=mb_convert_encoding($product->getsubCategoryId(), 'UTF-16LE', 'UTF-8');
    $arr2[5]=mb_convert_encoding($product->getQuantityProduct(), 'UTF-16LE', 'UTF-8');
    $out = implode(chr(0x09).chr(0x00), $arr2);
    fputs($file, $out.chr(0x0A).chr(0x00));
     }
   }
    fclose($file);
    }
  }

  function 
  tabledisieng (string $str)
  {
    //table desing
          echo ' <div class="row">
         <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">'.$str.'</h3>
            <div class="table table-sm" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מספר מוצר</th>
                            <th>שם מוצר </th>
                            <th>תמונה</th>
                            <th>מחיר</th>
                            <th>קטגוריה</th>
                            <th>תת קטגוריה</th>
                             <th>כמות</th>
                        </tr> 
                </thead> ';

  }

   

    //function of most lovely product
    function _62()
    {
          $db=new dbClass();
          $productarr=array();
          $productarr=$db->ProductOrder();//get all products in order
          foreach ($productarr as $arr)
          {
            $arr->setQuantityInOrder_Product(0);//set product quantity in order as 0
             $arr2=$db->QuantityofProduct($arr->getProductIDInOrder_Product());
             foreach ($arr2 as $arr3) {
              $arr->setQuantityInOrder_Product($arr3->getQuantityInOrder_Product()+$arr->getQuantityInOrder_Product());//set all quantity of product in order 
             }
         }


         //sort products by quantity 
        for($i=0;$i<count($productarr);$i++)
        {
          for($j=0;$j<count($productarr);$j++)
          {
            if($productarr[$i]->getQuantityInOrder_Product()>$productarr[$j]->getQuantityInOrder_Product())
            {
              $swap=$productarr[$i];
              $productarr[$i]=$productarr[$j];
              $productarr[$j]=$swap;
            }
          }

        }

        $product=array();
        $i=0;
        foreach ($productarr as $arr)
        {
          $product[$i]=$db->getProductById($arr->getProductIDInOrder_Product());
          $i++;  
        }

       $str="מוצרים נמכרים  ביותר";
       tabledisieng($str);
                
          //put data in table      
       $j=0;
       for($i=0;$i<count($product)&&$j<5;$i++)
         {
           
           if($product[$i][0]->getProductStatus()=='פעיל')
           {
         echo'<tr> 
            <td>'.$product[$i][0]->getProductId().'</td>
                <td>'.$product[$i][0]->getProductName().'</td>
                <td><img src="'.$product[$i][0]->getimage().'" style="width:40%; hight:30%;"></td>
                <td>'.$product[$i][0]->getUnitPrice().'</td> 
                <td>'.$product[$i][0]->getCategoryId().'</td>
                <td>'.$product[$i][0]->getsubCategoryId().'</td>
                <td>'.$product[$i][0]->getQuantityProduct().'</td>
              </tr>';
              $j++;
            }
            }

      echo '<form method="POST">
    <button type="submit" name="MostlovlyProducts" class="btn btn-primary">להוריד דוח</button>
    </form>';

    if(isset($_POST['MostlovlyProducts']))
    {
      $file=fopen('Reports/מוצרים הנמכרים ביותר .csv','w');
      $title=array(array('מספר מוצר','שם מוצר','מחיר','קטגוריה','תת קטגוריה'));
     
      fputs($file, chr(0xFF) . chr(0xFE));
    foreach ($title as $fields) {
    $out = '';
    foreach ($fields as $k => $v){
        $fields[$k] = mb_convert_encoding($v, 'UTF-16LE', 'UTF-8');        
    }
    $out = implode(chr(0x09).chr(0x00), $fields);
    fputs($file, $out.chr(0x0A).chr(0x00));
  }
   
   $arr2=array();
   for($i=0;$i<count($product)&&$i<5;$i++)
    {
      $arr2[0]=mb_convert_encoding($product[$i][0]->getProductId(), 'UTF-16LE', 'UTF-8');
      $arr2[1]=mb_convert_encoding($product[$i][0]->getProductName(), 'UTF-16LE', 'UTF-8');
      $arr2[2]=mb_convert_encoding($product[$i][0]->getUnitPrice(), 'UTF-16LE', 'UTF-8');
       $arr2[3]=mb_convert_encoding($product[$i][0]->getCategoryId(), 'UTF-16LE', 'UTF-8');
         $arr2[4]=mb_convert_encoding($product[$i][0]->getsubCategoryId(), 'UTF-16LE', 'UTF-8');

   $out = implode(chr(0x09).chr(0x00), $arr2);
    fputs($file, $out.chr(0x0A).chr(0x00));
     }
   
    fclose($file);
  }
}

    //order reports by date 
    function _63()
    {
          
      OrderDateDesing();//page desing
      $db=new dbClass();
      $orderdate=array();
      if(isset($_POST['btnSubmitDate']))
      {
        if(isset($_POST['date1'])&&isset($_POST['date2']))
        {
          //get date 
          $date1=$_POST['date1'];
          $date2=$_POST['date2'];

          $orderdate=$db->OrdertBetweenDate($date1,$date2);//return all orders between tow dates
           echo  '
           <div class="table table-sm" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מסםר הזמנה</th>
                            <th>תאריך הזמנה </th>
                            <th>ת.ז לקוח</th>
                            <th>סטטוס</th>
                            <th>ת.ז עובד</th>
                        </tr> 
                </thead> ';
                foreach($orderdate as $date){
                  $employee=$db->EmployeeByOrder($date->getOrderId());//get order employee
                  echo ' <tr>
                <td>'.$date->getOrderId().'</td> 
                <td>'.$date->getOrderDate().'</td>
                <td>'.$date->getOCustomerId().'</td>
                <td>'.$date->getStatus().'</td>
              ';
              if(count($employee)>0)
                echo '<td>'.$employee[0]->getEmployeesId().'</td></tr>';
              else
                echo '<td>---</td></tr>';
               }



                }


        }
        if(isset($_POST['btnSubmitDate']))
        {
            $file=fopen('Reports/ הזמנות לפי תאריכי '.$date1.'-'. $date2.'.csv','w');
      $title=array(array('מסםר הזמנה','תאריך הזמנה','ת.ז לקוח','סטטוס','ת.ז עוובד'));
      fputs($file, chr(0xFF) . chr(0xFE));
    foreach ($title as $fields) {
    $out = '';
    foreach ($fields as $k => $v){
        $fields[$k] = mb_convert_encoding($v, 'UTF-16LE', 'UTF-8');        
    }
    $out = implode(chr(0x09).chr(0x00), $fields);
    fputs($file, $out.chr(0x0A).chr(0x00));
  }
  $arr=array();
   foreach($orderdate as $date){
    $out='';
    $employee=$db->EmployeeByOrder($date->getOrderId());//get order employee
    $arr[0]=mb_convert_encoding($date->getOrderId(), 'UTF-16LE', 'UTF-8');
    $arr[1]=mb_convert_encoding($date->getOrderDate(), 'UTF-16LE', 'UTF-8');
    $arr[2]=mb_convert_encoding($date->getOCustomerId(), 'UTF-16LE', 'UTF-8');
    $arr[3]=mb_convert_encoding($date->getStatus(), 'UTF-16LE', 'UTF-8');
    if(count($employee)>0){
     $arr[4]=mb_convert_encoding($employee[0]->getEmployeesId(), 'UTF-16LE', 'UTF-8');
     }

     else{
                 $arr[4]='';
               }

      $out = implode(chr(0x09).chr(0x00), $arr);
      fputs($file, $out.chr(0x0A).chr(0x00));
               }
               fclose($file);

         }
      }

        


    

    //datee order page desing
    function OrderDateDesing()
    {
      echo '<div class="row">
         <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">הזמנות לפי תארכים</h3>
        <form method="POST" >
         <label ><h3>מ תאריך</h3> </label><input type="date" name="date1" required style="margin-left:5%;">
        <label><h3>עד תאריך</h3> </label> <input type="date" name="date2" required> 
        <br><br>
        <button type="submit" class="btn btn-primary" name="btnSubmitDate">אישור</button>
        </form>';
    }

    //open  orders above week 
    function _64()
    {

       $db=new dbClass();

       $order=$db->NotEndProcess();
      
          echo  ' <div class="row">
         <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">הזמנת שבטיפול מעל שבוע </h3>
          <div class="table table-sm" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מספר הזמנה</th>
                            <th>תאריך הזמנה </th>
                            <th>ת.ז לקוח</th>
                            <th>סטטוס</th>
                            <th>ת.ז עובד</th>
                        </tr> 
                </thead>
                <form method="POST">
                <button type="submit" name="reportorder1" class="btn btn-primary">להוריד דוח</button>
                </form> ';
               
                foreach($order as $date){
                  $employee=$db->EmployeeByOrder($date->getOrderId());//get order employee
                  $date1=$date->getOrderDate();
            
                  $newDate = date("m.d.y",strtotime($date1."+7 day"));
                  $datenow=date("m.d.y"); 

                  if($datenow>$newDate)
                  {
                    $arr[0]=mb_convert_encoding($date->getOrderId(), 'UTF-16LE', 'UTF-8');
                  echo ' <tr>
                <td>'.$date->getOrderId().'</td> 
                <td>'.$date->getOrderDate().'</td>
                <td>'.$date->getOCustomerId().'</td>
                <td>'.$date->getStatus().'</td>
              ';
              if(count($employee)>0)
                echo '<td>'.$employee[0]->getEmployeesId().'</td></tr>';
              else
                echo '<td>---</td></tr>';
               }
    }


    echo '</table>
             <div><div>';

             if(isset($_POST['reportorder1']))
             {
      $file=fopen('Reports/הזמנות שבטיפול מעל שבוע.csv','w');
      $title=array(array('מספר הזמנה','תאריך הזמנה','ת.ז לקוח','סטטוס','ת.ז עוובד'));
      fputs($file, chr(0xFF) . chr(0xFE));
    foreach ($title as $fields) {
    $out = '';
    foreach ($fields as $k => $v){
        $fields[$k] = mb_convert_encoding($v, 'UTF-16LE', 'UTF-8');        
    }
    $out = implode(chr(0x09).chr(0x00), $fields);
    fputs($file, $out.chr(0x0A).chr(0x00));
  }
  $arr=array();
  
  foreach($order as $date){
   $employee=$db->EmployeeByOrder($date->getOrderId());//get order employee
   $date1=$date->getOrderDate();
   $newDate = date("d.m.Y",strtotime($date1."+7 day"));
   $datenow=date("d.m.y");
   if($datenow>$newDate)
    {
          $employee=$db->EmployeeByOrder($date->getOrderId());//get order employee
    $arr[0]=mb_convert_encoding($date->getOrderId(), 'UTF-16LE', 'UTF-8');
    $arr[1]=mb_convert_encoding($date->getOrderDate(), 'UTF-16LE', 'UTF-8');
    $arr[2]=mb_convert_encoding($date->getOCustomerId(), 'UTF-16LE', 'UTF-8');
    $arr[3]=mb_convert_encoding($date->getStatus(), 'UTF-16LE', 'UTF-8');
    if(count($employee)>0){
     $arr[4]=mb_convert_encoding($employee[0]->getEmployeesId(), 'UTF-16LE', 'UTF-8');
     }

     else{
           $arr[4]='';
        }
      $out = implode(chr(0x09).chr(0x00), $arr);
      fputs($file, $out.chr(0x0A).chr(0x00));
               }
           
             }
    fclose($file);

  }
}
      

//function of employee order 
  function _65()
  {
    $db=new dbClass();
           $employeeArr=array();
        
              echo ' <div class="row">
        <div class="container col-md-2 col-lg-2 col-xs-2 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div  class="container col-md-8 col-lg-8 col-xs-4 col-sm-4 ">
        <h3 style="margin-top:10%; margin-bottom:5%;">חיפוש הזמנות לפי ת.ז עובד</h3>
        <form method="post">
        <br><br>
  <div  dir="ltr" class="input-group col-xs-6">
    <input type="text" class="form-control" placeholder="חיפוש לפי ת.ז"  dir="rtl" name="searchbynamebyemployee" maxlength="9" minlength="9">
    <span class="input-group-btn" dir="rtl">
      <button class="btn btn-primary" name="searchemployee" >
      <span   class="glyphicon glyphicon-search">
      </span> חיפוש
      </button>
    </span>
  </div></form>
  <br><br>';
  
     if(isset($_POST['searchbynamebyemployee'])&&isset($_POST['searchemployee'])) 
          {
            if(strlen($_POST['searchbynamebyemployee'])>0){
               searchEmployeebyOrder();
             }
             else
             {
              return;
             }
          }

         
  }
function searchEmployeebyOrder()
{
   if(isset($_POST['searchbynamebyemployee'])&&isset($_POST['searchemployee'])) 
          {
             $EmployeeArr=array();
             $db=new dbClass();
             $EmployeeArr=$db->getEmployeeOrderinfo($_POST['searchbynamebyemployee']);
          echo '   <div class="table" style="margin-bottom:15%;" >
                <table class="table" dir="ltr">
                    <thead>      <tr>
                            <th>מספר הזמנה</th>
                            <th>תאריך הזמנה </th>
                            <th>ת.ז של לקוח</th>
                            <th>סטטוס</th>
                        </tr> 
                </thead> ';
           if(count($EmployeeArr)==0)
           {
            echo ' <div class="row">
        <div class="container col-md-5 col-lg-5 col-xs-3 col-sm-3">
            <!--Empty 5 Columns to Move form-signin to the center-->
        </div>
        <div class="container col-md-3 col-lg-3 col-xs-5 col-sm-5 ">
                <h3 style="margin-top:15%;margin-bottom:15%; color:red;">*לעובד זה לא קיימות הזמנות</h3>
                </div></div>';
            return;
           }
          foreach ($EmployeeArr as $arr) {
            $order=$db->getOrderById($arr->getOrderId());
            echo'<tr> 
              <td>'.$order[0]->getOrderId().'</td>
                <td>'.$order[0]->getOrderDate().'</td>
                <td>'.$order[0]->getOCustomerId().'</td>
                <td>'.$order[0]->getStatus().'</td>
              </tr>';
          }
         
    }
  echo
             ' </table>
            </div>
        </div>
    </div>
';
 if(isset($_POST['searchemployee']))
          {
          $file=fopen('Reports/הזמנות לפי עובד'.$_POST['searchbynamebyemployee'].'.csv','w');
          $title=array(array('מספר הזמנה','תאריך הזמנה','ת.ז לקוח','סטטוס'));
           fputs($file, chr(0xFF) . chr(0xFE));
        foreach ($title as $fields) {
        $out = '';
    foreach ($fields as $k => $v){
        $fields[$k] = mb_convert_encoding($v, 'UTF-16LE', 'UTF-8');        
    }
    $out = implode(chr(0x09).chr(0x00), $fields);
    fputs($file, $out.chr(0x0A).chr(0x00));
  }
          $arr2=array();
          foreach ($EmployeeArr as $arr) {
            $out='';
            $order=$db->getOrderById($arr->getOrderId());
           $arr2[0]=mb_convert_encoding($order[0]->getOrderId(), 'UTF-16LE', 'UTF-8');
           $arr2[1]= mb_convert_encoding($order[0]->getOrderDate(), 'UTF-16LE', 'UTF-8');
           $arr2[2]= mb_convert_encoding($order[0]->getOCustomerId(), 'UTF-16LE', 'UTF-8');
           $arr2[3]=mb_convert_encoding($order[0]->getStatus(), 'UTF-16LE', 'UTF-8');
            $out = implode(chr(0x09).chr(0x00), $arr2);
            fputs($file, $out.chr(0x0A).chr(0x00));
          }
           fclose($file);

          }

}

       if(isset($_GET['category']))
          {
             $category=$_GET['category'];
             $str= '_';
               $function= $str.$category;
               $function();
                      
          }

      ?>
     <div class="Footer">
      <?php getFooter();?>
    </div>
  </body>
</html>